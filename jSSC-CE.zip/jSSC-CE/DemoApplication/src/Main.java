package jsscce_terminal;

/**
 *
 * @author scream3r
 */
public class Main {

    public static Form form;
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        form = new Form();
        form.setVisible(true);
    }

}
