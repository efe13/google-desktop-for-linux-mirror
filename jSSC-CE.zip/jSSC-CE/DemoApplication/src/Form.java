package jsscce_terminal;

import java.awt.Button;
import java.awt.Choice;
import java.awt.Dialog;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.Panel;
import java.awt.TextArea;
import java.awt.TextField;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import jssc.SerialPort;
import jssc.SerialPortEvent;
import jssc.SerialPortEventListener;

/**
 *
 * @author scream3r
 */
public class Form extends Frame {

    private TextField portName = new TextField();
    private Button buttonOpen = new Button("Open port");
    private Choice baudRateChoice = new Choice();
    private Choice dataBitsChoice = new Choice();
    private Choice stopBitsChoice = new Choice();
    private Choice parityChoice = new Choice();
    private TextArea input = new TextArea("", 6, 34, 1);
    private TextArea output = new TextArea("", 6, 34, 1);

    private SerialPort serialPort;
    private int baudRate = 9600;
    private int dataBits = 8;
    private int stopBits = 1;
    private int parity = 0;

    public Form(){
        
        setLayout(new FlowLayout());
        Dimension localDimension = Toolkit.getDefaultToolkit().getScreenSize();
        setLocation(localDimension.width / 2 - 120, localDimension.height / 2 - 150);
        setSize(240, 320);
        
        setTitle("jSSC-CE Terminal");

        baudRateChoice.addItem("300");
        baudRateChoice.addItem("1200");
        baudRateChoice.addItem("2400");
        baudRateChoice.addItem("3600");
        baudRateChoice.addItem("9600");
        baudRateChoice.addItem("14400");
        baudRateChoice.addItem("28800");
        baudRateChoice.addItem("38400");
        baudRateChoice.addItem("57600");
        baudRateChoice.addItem("115200");

        dataBitsChoice.addItem("5");
        dataBitsChoice.addItem("6");
        dataBitsChoice.addItem("7");
        dataBitsChoice.addItem("8");

        stopBitsChoice.addItem("1");
        stopBitsChoice.addItem("1.5");
        stopBitsChoice.addItem("2");

        parityChoice.addItem("NONE");
        parityChoice.addItem("ODD");
        parityChoice.addItem("EVEN");
        parityChoice.addItem("MARK");
        parityChoice.addItem("SPACE");

        Panel panelPortName = new Panel();
        GridLayout gridPortName = new GridLayout(1, 3);
        panelPortName.setLayout(gridPortName);
        panelPortName.add(new Label("PortName:"));
        panelPortName.add(portName);
        panelPortName.add(buttonOpen);
        buttonOpen.addActionListener(new OpenCloseListener());
        add(panelPortName);

        Panel panelSettings = new Panel();
        GridLayout gridSettings = new GridLayout(2, 4);
        gridSettings.setVgap(5);
        panelSettings.setLayout(gridSettings);
        panelSettings.add(new Label(" BaudRate:"));
        panelSettings.add(baudRateChoice);
        panelSettings.add(new Label(" DataBits:"));
        panelSettings.add(dataBitsChoice);
        panelSettings.add(new Label(" StopBits:"));
        panelSettings.add(stopBitsChoice);
        panelSettings.add(new Label(" Parity:"));
        panelSettings.add(parityChoice);
        add(panelSettings);

        add(new Label("Input Text Area"));
        add(input);
        add(new Label("Ouput Text Area"));
        add(output);
        output.addKeyListener(new OutputListener());

        baudRateChoice.addItemListener(new BaudListener());
        dataBitsChoice.addItemListener(new DataListener());
        stopBitsChoice.addItemListener(new StopListener());
        parityChoice.addItemListener(new ParityListener());
        portName.setText("COM1:");
        baudRateChoice.select("9600");
        dataBitsChoice.select("8");
        stopBitsChoice.select("1");
        parityChoice.select("NONE");

        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                System.exit(0);
            }
        });
    }

    private class OutputListener implements KeyListener {

        public void keyTyped(KeyEvent e) {
            if(serialPort.isOpened()){
                try {
                    serialPort.writeBytes(new byte[]{(byte)e.getKeyChar()});
                }
                catch (Exception ex) {
                    new ErrorDialog("Can't write data");
                }
            }
        }

        public void keyPressed(KeyEvent e) {
            
        }

        public void keyReleased(KeyEvent e) {
        }
    }
    
    private class BaudListener implements ItemListener {

        public void itemStateChanged(ItemEvent e) {
            baudRate = Integer.valueOf(e.getItem().toString());
        }
    }

    private class DataListener implements ItemListener {

        public void itemStateChanged(ItemEvent e) {
            dataBits = Integer.valueOf(e.getItem().toString());
        }
    }

    private class StopListener implements ItemListener {

        public void itemStateChanged(ItemEvent e) {
            String value = e.getItem().toString();
            if(value.equals("1.5")){
                value = "3";
            }
            stopBits = Integer.valueOf(value);
        }
    }

    private class ParityListener implements ItemListener {

        public void itemStateChanged(ItemEvent e) {
            String value = e.getItem().toString();
            if(value.equals("NONE")){
                parity = 0;
            }
            else if(value.equals("ODD")){
                parity = 1;
            }
            else if(value.equals("EVEN")){
                parity = 2;
            }
            else if(value.equals("MARK")){
                parity = 3;
            }
            else if(value.equals("SPACE")){
                parity = 4;
            }
        }
    }

    private class OpenCloseListener implements ActionListener {

        public void actionPerformed(ActionEvent e) {
            String command = e.getActionCommand().toString();
            if(command.equals("Open port")){
                serialPort = new SerialPort(portName.getText());
                try {
                    if(serialPort.openPort()){
                        if(serialPort.setParams(baudRate, dataBits, stopBits, parity)){
                            serialPort.addEventListener(new Reader());
                            buttonOpen.setLabel("Close port");
                        }
                        else {
                            new ErrorDialog("Can't set params");
                        }
                    }
                    else {
                        new ErrorDialog("Can't open port");
                    }
                }
                catch (Exception ex) {
                    new ErrorDialog(ex.getMessage());
                }
            }
            else {
                try {
                    serialPort.closePort();
                    buttonOpen.setLabel("Open port");
                }
                catch (Exception ex) {
                    new ErrorDialog("Can't close port");
                }
            }
        }
    }

    private class ErrorDialog {

        public ErrorDialog(String error){
            final Dialog dialog = new Dialog(Main.form, "Error", true);
            dialog.setSize(200, 50);
            dialog.setLayout(new GridLayout(1, 1));
            Label label = new Label(error);
            label.setAlignment(Label.CENTER);
            dialog.add(label);
            dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                public void windowClosing(java.awt.event.WindowEvent evt) {
                    dialog.dispose();
                }
            });
            dialog.setVisible(true);
        }
    }

    private class Reader implements SerialPortEventListener {

        public void serialEvent(SerialPortEvent serialPortEvent) {
            try {
                input.append(new String(serialPort.readBytes(serialPortEvent.getEventValue())));
            }
            catch (Exception ex) {
                 new ErrorDialog("Can't read data");
            }
        }
    }

}