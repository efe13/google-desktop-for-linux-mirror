/* jSSC-CE (Java Simple Serial Connector - CE) - serial port communication library
 * for Windows CE.
 * 
 * © Alexey Sokolov (scream3r), 2011.
 *
 * This file is part of jSSC-CE.
 *
 * jSSC-CE is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * jSSC-CE is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with jSSC-CE. If not, see <http://www.gnu.org/licenses/>.
 *
 * If you use jSSC-CE in public project you can inform me about this by e-mail,
 * of course if you want it.
 *
 * e-mail: scream3r.org@gmail.com
 * web-site: www.scream3r.org
 */
package jssc;

/**
 *
 * @author scream3r
 */
public class SerialNativeInterface {

    static {
        System.loadLibrary("jSSC");
    }

    /**
     * Port opening. Name of the port to be opened shall be sent to the method.
     *
     * @return Method returns <b>handle</b> of opened port or <b>-1</b> if opening of the port
     * was unsuccessful.
     */
    public native int openPort(String portName);

    /**
     * Setting the parameters of opened port.
     *
     * @param handle handle of opened port.
     * @param baudRate data transfer rate.
     * @param dataBits number of data bits.
     * @param stopBits number of stop bits.
     * @param parity parity.
     *
     * @return If the operation is successfully completed, the method returns
     * true, otherwise false.
     */
    public native boolean setParams(int handle, int baudRate, int dataBits, int stopBits, int parity);

    /**
     * Purge of input and output buffer.
     *
     * @param handle handle of opened port.
     * @param flags flags specifying required actions for purgePort method.
     *
     * @return If the operation is successfully completed, the method returns
     * true, otherwise false.
     */
    public native boolean purgePort(int handle, int flags);

    /**
     * Port closing.
     *
     * @param handle handle of opened port.
     *
     * @return If the operation is successfully completed, the method returns
     * true, otherwise false.
     */
    public native boolean closePort(int handle);

    /**
     * Setting of events mask.
     *
     * @param handle handle of opened port.
     * @param mask event mask.
     *
     * @return If the operation is successfully completed, the method returns
     * true, otherwise false.
     */
    public native boolean setEventsMask(int handle, int mask);

    /**
     * Getting of events mask for the port.
     *
     * @param handle handle of opened port.
     *
     * @return Method returns event mask as a variable of <b>int</b> type.
     */
    public native int getEventsMask(int handle);

    /**
     * Waiting of events.
     *
     * @param handle handle of opened port.
     *
     * @return Method returns two-dimensional array containing event types and
     * their values (<b>events[i][0] - event type, events[i][1] - event value</b>).
     */
    public native int[][] waitEvents(int handle);

    /**
     * RTS line status change.
     *
     * @param handle handle of opened port.
     * @param value <b>true - ON, false - OFF</b>.
     *
     * @return If the operation is successfully completed, the method returns
     * true, otherwise false.
     */
    public native boolean setRTS(int handle, boolean value);

    /**
     * DTR line status change.
     *
     * @param handle handle of opened port.
     * @param value <b>true - ON, false - OFF</b>.
     *
     * @return If the operation is successfully completed, the method returns
     * true, otherwise false.
     */
    public native boolean setDTR(int handle, boolean value);

    /**
     * Reading data from port.
     *
     * @param handle handle of opened port.
     * @param byteCount number of bytes required to read.
     *
     * @return Method returns the array of read bytes.
     */
    public native byte[] readBytes(int handle, int byteCount);

    /**
     * Writing data to port.
     *
     * @param handle handle of opened port.
     * @param buffer array of bytes to write.
     *
     * @return If the operation is successfully completed, the method returns
     * true, otherwise false.
     */
    public native boolean writeBytes(int handle, byte[] buffer);

    /**
     * Getting lines status.
     *
     * @param handle handle of opened port.
     *
     * @return Method returns the array containing information about lines in following order:
     * <br><b>element 0</b> - status of <b>CTS</b> line</br>
     * <br><b>element 1</b> - status of <b>DSR</b> line</br>
     * <br><b>element 2</b> - status of <b>RING</b> line</br>
     * <br><b>element 3</b> - status of <b>RLSD</b> line</br>
     */
    public native int[] getLinesStatus(int handle);
}
