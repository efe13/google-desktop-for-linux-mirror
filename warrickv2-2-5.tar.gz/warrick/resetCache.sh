rm -r -f testCache*
rm ./cache/*
echo "" > cache.o 
