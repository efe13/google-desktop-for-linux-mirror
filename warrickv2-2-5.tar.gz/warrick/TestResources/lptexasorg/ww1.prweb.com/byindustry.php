<HTML>
<HEAD><base href="http://ww1.prweb.com:80/byindustry.php?prcatid=62" />
<TITLE>America - Post 9/11 Press Releases</TITLE>
<META NAME="description" CONTENT="PR Web - Press Release Distribution.  Online Business Promotion. Public Relations Portal.">
<META NAME="keywords" CONTENT="press release, public relations, publicity, news, promotion, free, marketing, url, web site, advertising, marketing, industry">

<script language="javascript">

var win = null;
function NewWindow(mypage,myname,w,h){
LeftPosition = (screen.width) ? (screen.width-w)/2 : 0;
TopPosition = (screen.height) ? (screen.height-h)/2 : 0;
settings =
'height='+h+',width='+w+',top='+TopPosition+',left='+LeftPosition+',scrollbars=yes,resizable=no'
win = window.open(mypage,myname,settings)
}

</script>
<style type="text/css">
<!--
.bgtile {
	background-image: url(images/bg_tile.gif);
	background-repeat: repeat-x;
}
.bgmast {
	background-image: url(images/mast2.jpg);
	background-repeat: no-repeat;
}
.ddtext {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 10px;
	font-style: normal;
	font-weight: normal;
	font-variant: normal;
}
.leftnavtext {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 12px;
	font-style: normal;
	font-weight: normal;
	text-decoration: underline;
	color: #000066;
}
.slogan {
	background-image: url(images/mast1.gif);
	background-repeat: no-repeat;
}
-->
</style>
<script language="JavaScript" type="text/JavaScript">
<!--


function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
//-->
</script>
</head>

<body link="#006699" vlink="#006699" alink="#666666" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0" class="bgtile" onLoad="MM_preloadImages('images/home_over.gif','images/about_over.gif','images/submit_over.gif','images/prfirms_over.gif','images/contact_over.gif','images/editors_over.gif','images/search_over.gif','images/custom_newsfeed_down.jpg','images/free_syndication_down.jpg','images/login_down.jpg','images/free_email_down.jpg','images/not_member_down.jpg')">
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}

function MM_jumpMenu(targ,selObj,restore){ //v3.0
  eval(targ+".location='"+selObj.options[selObj.selectedIndex].value+"'");
  if (restore) selObj.selectedIndex=0;
}
//-->
</script>
<body onLoad="MM_preloadImages('images/home_over.gif','images/about_over.gif','images/submit_over.gif','images/prfirms_over.gif','images/contact_over.gif','images/editors_over.gif','images/search_over.gif','images/custom_newsfeed_down.jpg','images/login_down.jpg','images/not_member_down.jpg','images/free_syndication_down.jpg','images/free_email_down.jpg')"> <table width="750" border="0" cellspacing="0" cellpadding="0">
  <tr align="left" valign="bottom"> 
    <td width="170" height="68" align="center" valign="middle"> <a href="http://www.prweb.com"><img src="images/logo.gif" width="154" height="52" border="0"></a></td>
    <td width="580" align="right" valign="top"><font size="1">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br>
      </font>
<table width="95%" border="0" cellspacing="0" cellpadding="1">
        <tr> 
          <td bgcolor="#999999"> <table width="100%" border="0" cellspacing="0" cellpadding="2">
              <tr> 
                <td bgcolor="#FFFFFF"> <p><font face="Verdana, Arial, Helvetica, sans-serif" size="2">PR 
                    Web has provided free online press release distribution since 
                    1997. Why not tell a friend about this service today? <a href="/tellsomeone.php">Read 
                    More <img src="images/go2.gif" width="35" height="14" border="0" align="absbottom"></a> 
                    </font></p></td>
              </tr>
            </table></td>
        </tr>
      </table></td>
  </tr>
  <tr align="left" valign="bottom"> 
    <td height="18" colspan="2"><table width="750" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td align="right" valign="top"><a href="http://www.prweb.com" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image4','','images/home_over.gif',1)"><img src="images/home_up.gif" name="Image4" width="55" height="18" border="0"></a><a href="http://www.prweb.com/about.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image5','','images/about_over.gif',1)"><img src="images/about_up.gif" name="Image5" width="54" height="18" border="0"></a><a href="https://secure.dataovation.com/prweb/" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image6','','images/submit_over.gif',1)"><img src="images/submit_up.gif" name="Image6" width="105" height="18" border="0"></a><a href="http://www.prweb.com/prfirms.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image7','','images/prfirms_over.gif',1)"><img src="images/prfirms_up.gif" name="Image7" width="70" height="18" border="0"></a><a href="http://www.prweb.com/contact.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image8','','images/contact_over.gif',1)"><img src="images/contact_up.gif" name="Image8" width="89" height="18" border="0"></a><a href="http://www.prweb.com/subscribe.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image9','','images/editors_over.gif',1)"><img src="images/editors_up.gif" name="Image9" width="131" height="18" border="0"></a><a href="http://www.prweb.com/htdig/search.html" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image10','','images/search_over.gif',1)"><img src="images/search_up.gif" name="Image10" width="112" height="18" border="0"></a></td>
        </tr>
      </table></td>
  </tr>
  <tr valign="middle"> 
    <td height="17" colspan="2" align="left" class="slogan"><span class="ddtext"><font color="#FFFFFF"><b><font color="#FFFFFF" face="Verdana, Arial, Helvetica, sans-serif" size="2"> 
      &nbsp;&nbsp; 
      February 7, 2003      </font></b></font></span></td>
  </tr>
  <tr align="left" valign="top"> 
    <td height="76" colspan="2"><table width="750" border="0" cellspacing="0" cellpadding="0">
        <tr valign="top"> 
          <td height="30" rowspan="2" align="left"><a href="http://www.prweb.com/subscribe.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image23','','images/custom_newsfeed_down.jpg',1)"><img src="images/custom_newsfeed.jpg" name="Image23" width="250" height="38" border="0"></a></td>
          <td width="325" rowspan="3" align="left"><img src="images/mast2.jpg" width="325" height="76"></td>
          <td align="left"><a href="https://secure.dataovation.com/prweb/login.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image25','','images/login_down.jpg',1)"><img src="images/login.jpg" name="Image25" width="174" height="21" border="0"></a></td>
        </tr>
        <tr valign="top"> 
          <td align="left"><a href="https://secure.dataovation.com/prweb/register.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image21','','images/not_member_down.jpg',1)"><img src="images/not_member.jpg" name="Image21" width="174" height="17" border="0"></a></td>
        </tr>
        <tr valign="top"> 
          <td height="30" align="left"><a href="http://www.prweb.com/rss.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image24','','images/free_syndication_down.jpg',1)"><img src="images/free_syndication.jpg" name="Image24" width="250" height="38" border="0"></a></td>
          <td align="left"><a href="http://mail.prweb.com" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image26','','images/free_email_down.jpg',1)"><img src="images/free_email.jpg" name="Image26" width="174" height="38" border="0"></a></td>
        </tr>
      </table></td>
  </tr>
  <tr align="left" valign="top"> 
    <td colspan="2"><table width="750" border="0" cellspacing="0" cellpadding="0">
        <tr valign="top"> 
          <td height="5" colspan="4" align="left"></td>
        </tr>
        <tr valign="top"> 
          <td width="0%" align="left">&nbsp;</td>
          <td width="27%" align="left" valign="bottom"> <form name="form1" method="post" action="http://www.prweb.com/byindustry.php">
              <select name="prcatid" class="ddtext" id="prcatid">
                <option selected>Select an Industry Release</option>
				<option value="1">Advertising</option>
<option value="2">Aerospace / Defense</option>
<option value="3">Agriculture</option>
<option value="4">Airlines</option>
<option value="62">America - Post 9/11</option>
<option value="5">Apparel / Textiles</option>
<option value="52">Architectural</option>
<option value="6">Automotive</option>
<option value="65">Biotechnology</option>
<option value="7">Chemical</option>
<option value="8">Computers</option>
<option value="9">Construction</option>
<option value="22">Consumer</option>
<option value="10">Economy</option>
<option value="11">Education</option>
<option value="12">Electronics</option>
<option value="61">Employment/Careers</option>
<option value="13">Entertainment</option>
<option value="14">Environment</option>
<option value="66">Events / Trade Shows</option>
<option value="15">Finance</option>
<option value="16">Food / Beverage</option>
<option value="17">Franchise</option>
<option value="18">Gaming</option>
<option value="19">Government</option>
<option value="20">Healthcare</option>
<option value="21">Home Schooling</option>
<option value="53">Hotel / Resorts</option>
<option value="23">Insurance</option>
<option value="24">Internet</option>
<option value="64">Investment</option>
<option value="56">Legal</option>
<option value="25">Leisure / Hospitality</option>
<option value="26">Machinery</option>
<option value="27">Maritime</option>
<option value="28">Markets</option>
<option value="29">Medical</option>
<option value="30">Mining / Metals</option>
<option value="51">Miscellaneous</option>
<option value="67">Music</option>
<option value="69">Network Marketing</option>
<option value="31">Non-profit</option>
<option value="32">Oil / Energy</option>
<option value="63">Open Source</option>
<option value="68">Opinion / Editorial</option>
<option value="33">Paper / Forest Products</option>
<option value="34">Pharmaceuticals</option>
<option value="59">Politics</option>
<option value="54">Print Media</option>
<option value="35">Publishing</option>
<option value="36">Radio</option>
<option value="37">Real Estate</option>
<option value="57">Religion</option>
<option value="39">Restaurants</option>
<option value="38">Retail</option>
<option value="40">Software</option>
<option value="41">Sports</option>
<option value="42">Stocks</option>
<option value="43">Supermarkets</option>
<option value="60">Technology</option>
<option value="44">Telecom</option>
<option value="45">Television</option>
<option value="46">Tobacco</option>
<option value="47">Trade</option>
<option value="48">Transportation</option>
<option value="49">Travel</option>
<option value="50">Utilities</option>
<option value="55">Volunteer</option>
              </select>
              <input name="imageField" type="image" src="images/go2.gif" align="bottom" width="35" height="14" border="0">
            </form></td>
          <td width="39%" align="left" valign="bottom"> <form name="msa" method="post" action="http://www.prweb.com/bymsa.php">
              <div align="left"> 
                <select name="msa" class="ddtext">
                  <option value="--" selected>Please Select MSA</option>
                  <option value="0080">Akron, OH</option>
                  <option value="0160">Albany-Schenectady-Troy, NY</option>
                  <option value="0200">Albuquerque, NM</option>
                  <option value="0010">All Regions (Including International)</option>
                  <option value="0240">Allentown-Bethlehem-Easton, PA</option>
                  <option value="0440">Ann Arbor, MI</option>
                  <option value="0520">Atlanta, GA</option>
                  <option value="0640">Austin-San Marcos, TX</option>
                  <option value="0720">Baltimore, MD</option>
                  <option value="0760">Baton Rouge, LA</option>
                  <option value="0875">Bergen-Passaic, NJ</option>
                  <option value="1000">Birmingham, AL</option>
                  <option value="1080">Boise City, ID</option>
                  <option value="1120">Boston, MA-NH</option>
                  <option value="1160">Bridgeport, CT</option>
                  <option value="1280">Buffalo-Niagara Falls, NY</option>
                  <option value="1440">Charleston-North Charleston, SC</option>
                  <option value="1520">Charlotte-Gastonia-Rock Hill, NC-SC</option>
                  <option value="1560">Chattanooga, TN-GA</option>
                  <option value="1600">Chicago, IL</option>
                  <option value="1640">Cincinnati, OH-KY-IN</option>
                  <option value="1680">Cleveland-Lorain-Elyria, OH</option>
                  <option value="1720">Colorado Springs, CO</option>
                  <option value="1760">Columbia, SC</option>
                  <option value="1840">Columbus, OH</option>
                  <option value="1920">Dallas, TX</option>
                  <option value="2000">Dayton-Springfield, OH</option>
                  <option value="2020">Daytona Beach, FL</option>
                  <option value="2080">Denver, CO</option>
                  <option value="2120">Des Moines, IA</option>
                  <option value="2160">Detroit, MI</option>
                  <option value="2320">El Paso, TX</option>
                  <option value="2680">Fort Lauderdale, FL</option>
                  <option value="2700">Fort Myers-Cape Coral, FL</option>
                  <option value="2760">Fort Wayne, IN</option>
                  <option value="2800">Fort Worth-Arlington, TX</option>
                  <option value="2840">Fresno, CA</option>
                  <option value="2960">Gary, IN</option>
                  <option value="3000">Grand Rapids-Muskegon-Holland, MI</option>
                  <option value="3120">Greensboro-Winston-Salem-High Point, NC</option>
                  <option value="3160">Greenville-Spartanburg-Anderson, SC</option>
                  <option value="3240">Harrisburg-Lebanon-Carlisle, PA</option>
                  <option value="3280">Hartford, CT</option>
                  <option value="3320">Honolulu, HI</option>
                  <option value="3360">Houston, TX</option>
                  <option value="3480">Indianapolis, IN</option>
                  <option value="3600">Jacksonville, FL</option>
                  <option value="3640">Jersey City, NJ</option>
                  <option value="3760">Kansas City, MO-KS</option>
                  <option value="3840">Knoxville, TN</option>
                  <option value="4120">Las Vegas, NV-AZ</option>
                  <option value="4280">Lexington, KY</option>
                  <option value="4400">Little Rock-North Little Rock, AR</option>
                  <option value="4480">Los Angeles-Long Beach, CA</option>
                  <option value="4520">Lousiville, KY-IN</option>
                  <option value="4720">Madison, WI</option>
                  <option value="4920">Memphis, TN-AR-MS</option>
                  <option value="5000">Miami, FL</option>
                  <option value="5015">Middlesex-Somerset-Hunterdon, NJ</option>
                  <option value="5080">Milwaukee-Waukesha, WI</option>
                  <option value="5120">Minneapolis-St. Paul, MN-WI</option>
                  <option value="5160">Mobile, AL</option>
                  <option value="5190">Monmouth-Ocean, NJ</option>
                  <option value="5360">Nashville, TN</option>
                  <option value="5380">Nassau-Suffolk, NY</option>
                  <option value="5480">New Haven-Meriden, CT</option>
                  <option value="5560">New Orleans, LA</option>
                  <option value="5600">New York, NY</option>
                  <option value="5640">Newark, NJ</option>
                  <option value="5720">Norfolk-Virginia Beach-Newport News, VA-NC</option>
                  <option value="5775">Oakland, CA</option>
                  <option value="5880">Oklahoma City, OK</option>
                  <option value="5920">Omaha, NE-IA</option>
                  <option value="5945">Orange County, CA</option>
                  <option value="5960">Orlando, FL</option>
                  <option value="6160">Philadelphia, PA-NJ</option>
                  <option value="6200">Phoenix-Mesa, AZ</option>
                  <option value="6280">Pittsburgh, PA</option>
                  <option value="6440">Portland-Vancouver, OR-WA</option>
                  <option value="6480">Providence-Fall River-Warwick, RI-MA</option>
                  <option value="6640">Raleigh-Durham-Chapel Hill, NC</option>
                  <option value="6760">Richmond-Petersburg, VA</option>
                  <option value="6780">Riverside-San Bernardino, CA</option>
                  <option value="6840">Rochester, NY</option>
                  <option value="6920">Sacramento, CA</option>
                  <option value="7160">Salt Lake City-Ogden, UT</option>
                  <option value="7240">San Antonio, TX</option>
                  <option value="7320">San Diego, CA</option>
                  <option value="7360">San Francisco, CA</option>
                  <option value="7400">San Jose, CA</option>
                  <option value="7500">Santa Rosa, CA</option>
                  <option value="7510">Sarasota-Bradenton, FL</option>
                  <option value="7560">Scranton--Wilkes-Barre-Hazleton, PA</option>
                  <option value="7600">Seattle-Bellevue-Everett, WA</option>
                  <option value="7840">Spokane, WA</option>
                  <option value="8000">Springfield, MA</option>
                  <option value="7040">St. Louis, MO-IL</option>
                  <option value="8040">Stamford-Norwalk, CT</option>
                  <option value="8160">Syracuse, NY</option>
                  <option value="8200">Tacoma, WA</option>
                  <option value="8280">Tampa-St. Petersburg-Clearwater, FL</option>
                  <option value="8400">Toledo, OH</option>
                  <option value="8520">Tucson, AZ</option>
                  <option value="8560">Tulsa, OK</option>
                  <option value="8735">Ventura, CA</option>
                  <option value="8840">Washington, DC-MD-VA-WV</option>
                  <option value="8960">West Palm Beach-Boca Raton, FL</option>
                  <option value="9040">Wichita, KS</option>
                  <option value="9160">Wilmington-Newark, DE-MD</option>
                  <option value="9240">Worcester, MA-CT</option>
                  <option value="9320">Youngstown-Warren, OH</option>
                </select>
                <input name="imageField" type="image" src="images/go2.gif" align="bottom" width="35" height="14" border="0">
              </div>
            </form></td>
          <td width="34%" align="left" valign="bottom"> <form name="msa" method="post" action="http://www.prweb.com/bycountry.php">
              <select name="countrycode" class="ddtext">
                <option value="--" selected>Please Select Country</option>
                <option value="AF">Afghanistan</option>
                <option value="AL">Albania</option>
                <option value="DZ">Algeria</option>
                <option value="AA">All Countries</option>
                <option value="AS">American Samoa</option>
                <option value="AD">Andorra</option>
                <option value="AI">Anguilla</option>
                <option value="AQ">Antarctica</option>
                <option value="AG">Antigua & Barbuda</option>
                <option value="AR">Argentina</option>
                <option value="AM">Armenia</option>
                <option value="AU">Australia</option>
                <option value="AT">Austria</option>
                <option value="AZ">Azerbaijan</option>
                <option value="BS">Bahamas</option>
                <option value="BH">Bahrain</option>
                <option value="BB">Barbados</option>
                <option value="BY">Belarus</option>
                <option value="BE">Belgium</option>
                <option value="BZ">Belize</option>
                <option value="BO">Bolivia</option>
                <option value="BA">Bosnia & Herzegovina</option>
                <option value="BR">Brazil</option>
                <option value="IO">British Indian Ocean Territory</option>
                <option value="BN">Brunei Darussalam</option>
                <option value="BG">Bulgaria</option>
                <option value="CA">Canada</option>
                <option value="KY">Cayman Islands</option>
                <option value="CN">China</option>
                <option value="CO">Colombia</option>
                <option value="CK">Cook Islands</option>
                <option value="CR">Costa Rica</option>
                <option value="HR">Croatia</option>
                <option value="CY">Cyprus</option>
                <option value="CZ">Czech Republic</option>
                <option value="DK">Denmark</option>
                <option value="DO">Dominican Republic</option>
                <option value="EC">Ecuador</option>
                <option value="EG">Egypt</option>
                <option value="SV">El Salvador</option>
                <option value="EE">Estonia</option>
                <option value="ET">Ethiopia</option>
                <option value="FI">Finland</option>
                <option value="FR">France</option>
                <option value="GF">French Guiana</option>
                <option value="TF">French Southern Territories</option>
                <option value="DE">Germany</option>
                <option value="GI">Gibraltar</option>
                <option value="GR">Greece</option>
                <option value="GU">Guam</option>
                <option value="GT">Guatemala</option>
                <option value="HK">Hong Kong</option>
                <option value="HU">Hungary</option>
                <option value="IS">Iceland</option>
                <option value="IN">India</option>
                <option value="ID">Indonesia</option>
                <option value="IR">Iran, Islamic Republic Of</option>
                <option value="IE">Ireland</option>
                <option value="IL">Israel</option>
                <option value="IT">Italy</option>
                <option value="JM">Jamaica</option>
                <option value="JP">Japan</option>
                <option value="JO">Jordan</option>
                <option value="KZ">Kazakstan</option>
                <option value="KE">Kenya</option>
                <option value="KP">Korea, Democratic People's Republic</option>
                <option value="KR">Korea, Republic Of</option>
                <option value="KW">Kuwait</option>
                <option value="LV">Latvia</option>
                <option value="LB">Lebanon</option>
                <option value="LT">Lithuania</option>
                <option value="LU">Luxembourg</option>
                <option value="MO">Macau</option>
                <option value="MY">Malaysia</option>
                <option value="MT">Malta</option>
                <option value="MH">Marshall Islands</option>
                <option value="MU">Mauritius</option>
                <option value="MX">Mexico</option>
                <option value="MD">Moldova, Republic Of</option>
                <option value="MZ">Mozambique</option>
                <option value="MM">Myanmar</option>
                <option value="NA">Namibia</option>
                <option value="NL">Netherlands</option>
                <option value="AN">Netherlands Antilles</option>
                <option value="NZ">New Zealand</option>
                <option value="NG">Nigeria</option>
                <option value="NO">Norway</option>
                <option value="OM">Oman</option>
                <option value="PK">Pakistan</option>
                <option value="PA">Panama</option>
                <option value="PY">Paraguay</option>
                <option value="PE">Peru</option>
                <option value="PH">Philippines</option>
                <option value="PL">Poland</option>
                <option value="PT">Portugal</option>
                <option value="PR">Puerto Rico</option>
                <option value="RO">Romania</option>
                <option value="RU">Russian Federation</option>
                <option value="KN">Saint Kitts & Nevis</option>
                <option value="VC">Saint Vincent & The Grenadines</option>
                <option value="SM">San Marino</option>
                <option value="SA">Saudi Arabia</option>
                <option value="SC">Seychelles</option>
                <option value="SG">Singapore</option>
                <option value="SK">Slovakia</option>
                <option value="SI">Slovenia</option>
                <option value="ZA">South Africa</option>
                <option value="ES">Spain</option>
                <option value="LK">Sri Lanka</option>
                <option value="SE">Sweden</option>
                <option value="CH">Switzerland</option>
                <option value="TW">Taiwan, Province Of China</option>
                <option value="TH">Thailand</option>
                <option value="TK">Tokelau</option>
                <option value="TT">Trinidad & Tobago</option>
                <option value="TR">Turkey</option>
                <option value="TC">Turks & Caicos Islands</option>
                <option value="UG">Uganda</option>
                <option value="UA">Ukraine</option>
                <option value="AE">United Arab Emirates</option>
                <option value="GB">United Kingdom</option>
                <option value="UK">United Kingdom</option>
                <option value="US">United States</option>
                <option value="UM">United States Minor Outlying Islands</option>
                <option value="UY">Uruguay</option>
                <option value="UZ">Uzbekistan</option>
                <option value="VE">Venezuela</option>
                <option value="VG">Virgin Islands, British</option>
                <option value="VI">Virgin Islands, U.S.</option>
                <option value="YU">Yugoslavia</option>
                <option value="ZM">Zambia</option>
              </select>
              <input name="imageField" type="image" src="images/go2.gif" align="bottom" width="35" height="14" border="0">
            </form></td>
        </tr>
      </table></td>
  </tr>
</table><font size="1"><br>
&nbsp;&nbsp;</font>
<table width="95%" border="0" cellpadding="0" cellspacing="0">
  <tr align="left" valign="bottom"> 
    <td width="20%" valign="top"> 
       
<table width="200" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td width="10" rowspan="12" align="left" valign="middle">&nbsp;</td>
    <td height="20" colspan="2" align="left" valign="top"><font size="2" face="Arial, Helvetica, sans-serif" color="#FFFFFF"><a href="http://www.prweb.com/phpAds/click.php3?bannerID=2"><img src="http://www.prweb.com/phpAds/viewbanner.php3?bannerID=2" width=179 height=190 alt="PRWEB.COM User Testimonial" border=0></a>2</font><br>
      <br>
      </a></td>
    <td width="10" rowspan="12" align="left" valign="top">&nbsp;</td>
    <td width="1" rowspan="12" align="left" valign="top" bgcolor="#006699"><img src="images/blue_line.gif" width="1" height="5"></td>
  </tr>
  <tr> 
    <td width="10" height="20" align="left" valign="top">&nbsp;</td>
    <td width="169" height="20" align="left" valign="top"><img src="images/directory.gif" width="64" height="10"></td>
  </tr>
  <tr valign="middle"> 
    <td width="10" height="15" align="left" valign="top"><font size="2" face="Arial, Helvetica, sans-serif"><a href="/about.php"> 
      </a><img src="images/gray_dot.gif" width="5" height="10"></font></td>
    <td width="169" align="left" valign="top"><font size="2" face="Arial, Helvetica, sans-serif"><a href="/about.php" class="leftnavtext">About 
      PRWeb</a><font size="1"><br>
      &nbsp;&nbsp;</font> </font></td>
  </tr>
  <tr valign="middle"> 
    <td width="10" height="15" align="left" valign="top"><font size="2" face="Arial, Helvetica, sans-serif"><img src="images/gray_dot.gif" width="5" height="10"></font></td>
    <td width="169" align="left" valign="top"><font size="2" face="Arial, Helvetica, sans-serif"><a href="/faq.php" class="leftnavtext">Frequently 
      Asked Questions (FAQs)</a><font size="1"><br>
      &nbsp;&nbsp;</font> </font></td>
  </tr>
  <tr valign="middle"> 
    <td width="10" height="15" align="left" valign="top"><font size="2" face="Arial, Helvetica, sans-serif"><img src="images/gray_dot.gif" width="5" height="10"></font></td>
    <td width="169" align="left" valign="top"><font size="2" face="Arial, Helvetica, sans-serif"><a href="/tellsomeone.php" class="leftnavtext">Tell 
      a Friend or Colleague About PR Web</a></font></td>
  </tr>
  <tr valign="middle"> 
    <td width="10" align="left" valign="top">&nbsp;</td>
    <td width="169" align="left" valign="top">&nbsp;</td>
  </tr>
  <tr valign="middle"> 
    <td width="10" height="20" align="left" valign="top">&nbsp;</td>
    <td width="169" height="20" align="left" valign="top"><img src="images/h_get_news_feeds.gif" width="96" height="10"></td>
  </tr>
  <tr valign="middle"> 
    <td width="10" align="left" valign="top"><font size="2" face="Arial, Helvetica, sans-serif"><img src="images/gray_dot.gif" width="5" height="10"></font></td>
    <td width="169" align="left" valign="top"><font size="2" face="Arial, Helvetica, sans-serif"><a href="/subscribe.php" class="leftnavtext">Subscribe 
      to News Feeds - Free</a><font size="1"><br>
      &nbsp;&nbsp;</font> </font></td>
  </tr>
  <tr valign="middle"> 
    <td width="10" align="left" valign="top"><font size="2" face="Arial, Helvetica, sans-serif"><img src="images/gray_dot.gif" width="5" height="10"></font></td>
    <td width="169" align="left" valign="top"><font size="2" face="Arial, Helvetica, sans-serif"><a href="/rss.php" class="leftnavtext">Add 
      These Headlines to Your Web Site - Free</a></font></td>
  </tr>
  <tr valign="middle"> 
    <td width="10" align="left" valign="top">&nbsp;</td>
    <td width="169" align="left" valign="top">&nbsp;</td>
  </tr>
  <tr valign="middle"> 
    <td width="10" height="20" align="left" valign="top">&nbsp;</td>
    <td width="169" height="20" align="left" valign="top"><img src="images/h_submissions.gif" width="80" height="10"></td>
  </tr>
  <tr valign="middle"> 
    <td width="10" height="20" align="left" valign="top"><font size="2" face="Arial, Helvetica, sans-serif"><img src="images/gray_dot.gif" width="5" height="10"></font></td>
    <td width="169" align="left" valign="top"><font size="2" face="Arial, Helvetica, sans-serif"><a href="https://secure.dataovation.com/prweb/" class="leftnavtext">Distribute 
      Your Free Press Release Here</a></font></td>
  </tr>
</table>
    </td>
    <td width="80%" valign="top"> <table width="95%" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="2%" rowspan="2" align="left" valign="top"><p>&nbsp;</p>
            <p>&nbsp;</p>
            <p>&nbsp;</p>
            <p>&nbsp;</p></td>
          <td width="98%" height="20" align="left" valign="top"><font color="#CC0000" size="2" face="Verdana, Arial, Helvetica, sans-serif"><strong>Recent 
            Headlines &gt;&gt; <b><font face="Arial, Helvetica, sans-serif" color="#000000">America - Post 9/11</font></b></strong></font></td>
        </tr>
        <tr> 
          <td width="98%" align="left" valign="top"><p><font color="#000000" face="Verdana, Arial, Helvetica, sans-serif" size="1">Found 
              <b> 170 </b>news releases.</font></p>
            <p> <UL><p><a href="/releases/2003/2/prweb56656.php"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">
					<b>IS THE "WAR ON TERRORISM" A WAR ON YOUR CIVIL RIGHTS? - A PUBLIC FORUM</b></font></a> <font size="2" face="Verdana, Arial, Helvetica, sans-serif">
					On February 13, 2003, the Civil Rights Committee and Education Committee of the Asian American Bar Association of the Greater Bay Area (AABA) and the Commonwealth Club of California will be sponsoring a public forum to encourage everyone to take a closer look at the government�s �war on terrorism� and understand how it affects your everyday life. A panel of legal experts will discuss the scope of the government�s anti-terrorism policies.  The panel includes:  Bill Lann Lee, former Assistant US Attorney General for Civil Rights; Jayashri Srikantiah, staff attorney for the American Civil Liberties Union; Minette Kwok, immigration attorney and AILA Executive Board Member; and Lee Tien, senior staff attorney for the Electonic Frontier Foundation in San Francisco. - 2003-02-06</font> </p>
<p><a href="/releases/2003/2/prweb56654.php"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">
					<b>New Homeland Security 2003-2010 Industry and Market Analysis and Forecast Reports.
Detailed forecasts, by geography, technologies, products and markets
</b></font></a> <font size="2" face="Verdana, Arial, Helvetica, sans-serif">
					The new reports are designed to give decision makers in the investment, industry and homeland security community the overview and the detailed analysis they need when looking at the evolution of the industry and market over the next 7 years. - 2003-02-06</font> </p>
<p><a href="/releases/2003/2/prweb56501.php"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">
					<b>The Wall Street Transcript - Security and Homeland Defense Interview with Markland Technologies (MKLD:OTCBB) 
</b></font></a> <font size="2" face="Verdana, Arial, Helvetica, sans-serif">
					 - 2003-02-05</font> </p>
<p><a href="/releases/2003/2/prweb56525.php"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">
					<b>Markland Technologies Chairman Robert Tarini Talks To The Wall Street Transcript
</b></font></a> <font size="2" face="Verdana, Arial, Helvetica, sans-serif">
					The Wall Street Transcript has published an in-depth interview with Robert Tarini, Chairman of the Board of Markland Technologies (OTC: MKLD.OB), in which he talks at length about the Company�s future. 
 - 2003-02-05</font> </p>
<p><a href="/releases/2003/1/prweb56138.php"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">
					<b>Ray Derby was 'Homeland Security' before there was a 'Homeland Security'.</b></font></a> <font size="2" face="Verdana, Arial, Helvetica, sans-serif">
					For interviews and interest please contact Booksandauthors@aol.com or 910-264-9628 - 2003-01-31</font> </p>
<p><a href="/releases/2003/1/prweb55969.php"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">
					<b>Markland Technologies Announces Status on 
Security Products and Development Initiatives</b></font></a> <font size="2" face="Verdana, Arial, Helvetica, sans-serif">
					Markland Technologies Announces Status on 
Security Products and Development Initiatives - 2003-01-30</font> </p>
<p><img src="/images/smallstar.gif" width="10" height="10" align="absmiddle" alt="Upgraded $10.00"><a href="/releases/2003/1/prweb55309.php"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">
					<b>DANDELION BOOKS SIGNS PUBLISHING CONTRACT WITH MERIA HELLER </b></font></a> <font size="2" face="Verdana, Arial, Helvetica, sans-serif">
					TEMPE, AZ . . .  Dandelion Books has captured another �hot� title, THE AWAKENING OF AN AMERICAN: HOW MY COUNTRY BROKE MY HEART, by Internet celebrity, Meria Heller.  - 2003-01-23</font> </p>
<p><a href="/releases/2003/1/prweb55323.php"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">
					<b>Tie One On for Peace - The Peace Knot Project</b></font></a> <font size="2" face="Verdana, Arial, Helvetica, sans-serif">
					The Peace Knot is a physical representation of our collective desire for peace. Messages are written, sewn or embroidered on strips of cloth, string, rope, etc., and tied or "knotted" to each other. As these strips are added we'll create a large spherical knot that can be rolled around and added to. In this way, all our wishes for peace are bound to each other by a common goal. - 2003-01-23</font> </p>
<p><img src="/images/smallstar.gif" width="10" height="10" align="absmiddle" alt="Upgraded $10.00"><a href="/releases/2003/1/prweb55168.php"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">
					<b>Iraq Deployment -- Preparing Children for War


</b></font></a> <font size="2" face="Verdana, Arial, Helvetica, sans-serif">
					As the Iraq deadline nears, it's not only those children with loved ones in the Persian Gulf who will experience war anxieties," says Dr. Robert Butterworth, Ph.D., a Los Angeles-based psychologist who treated adults and children who experienced psychological difficulties during the 1991 Gulf War crisis.
 - 2003-01-22</font> </p>
<p><a href="/releases/2003/1/prweb54913.php"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">
					<b>Starting a New Business on the Internet today is not easy. You must have alot of energy, patience and the sheer will to survive. It can go either way: the sharks will eat you, or you will stay afloat and make it.</b></font></a> <font size="2" face="Verdana, Arial, Helvetica, sans-serif">
					K and K Creative Concepts was started around 20 years ago. When I say started, I mean only in my head, heart and soul.  - 2003-01-18</font> </p>
<p><a href="/releases/2003/1/prweb54069.php"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">
					<b>15 predictions for 2003 from internationally known psychic medium Tristan Rimbaud!</b></font></a> <font size="2" face="Verdana, Arial, Helvetica, sans-serif">
					Fifteen predictions for 2003 covering everything from the threat of war to J.Lo and Ben Afflecks marriage.  The "MTV generation" psychic steps up to the plate with international success.
 - 2003-01-09</font> </p>
<p><a href="/releases/2003/1/prweb53910.php"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">
					<b>2003 Disaster Recovery Planning Seminar schedule</b></font></a> <font size="2" face="Verdana, Arial, Helvetica, sans-serif">
					DisasterRecovery.com Inc is please to announce its enhanced 2003 Disaster Recovery Planning Seminar schedule. - 2003-01-06</font> </p>
<p><img src="/images/smallstar.gif" width="10" height="10" align="absmiddle" alt="Upgraded $25.00"><img src="/images/smallstar.gif" width="10" height="10" align="absmiddle" alt="Upgraded $25.00"><a href="/releases/2003/1/prweb53700.php"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">
					<b>January 2nd ~ National Motivation & Inspiration Day !
Cycling Into Guinness Record Book
</b></font></a> <font size="2" face="Verdana, Arial, Helvetica, sans-serif">
					January 2nd is National Motivation & Inspiration Day. In recognition of that day, Life Fitness and the founder of the day, Kevin L. McCrudden, are organizing a nationwide attempt to break the Guinness World Record for the most simultaneous participants on �stationary/static cycles.� 

At 9:00 a.m. EST, January 2, 2003, exercisers across the nation will hop on stationary bikes at participating fitness facilities and cycle for a minimum of 15 minutes to participate in the first Motivate America - CycleQuest event. Coordinators at each facility will document the total number of participants. The current record for �Mass Participation Stationary/Static Cycling� is 300 participants, which was established in 2001 in Bogot�, Columbia. - 2003-01-02</font> </p>
<p><img src="/images/smallstar.gif" width="10" height="10" align="absmiddle" alt="Upgraded $10.00"><a href="/releases/2002/12/prweb53229.php"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">
					<b>Life Fitness and Motivate America Attempt to Cycle Into the Guinness World Records Book for National Motivation & Inspiration Day ~ Jan. 2nd
</b></font></a> <font size="2" face="Verdana, Arial, Helvetica, sans-serif">
					Life Fitness of Chicago, IL and Kevin L. McCrudden of Long Island, NY and founder of National Motivation & Inspiration Day, are organizing a nationwide attempt to break the Guinness World Record for the most simultaneous participants on "stationary/static cycles" to commence at 9:00 a.m. EST on Jan. 2, 2003,which is National Motivation & Inspiration Day. - 2002-12-22</font> </p>
<p><a href="/releases/2002/12/prweb52345.php"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">
					<b>MISTAKEN IDENTITY - Celebrates Cultural Diversity in American TV programming</b></font></a> <font size="2" face="Verdana, Arial, Helvetica, sans-serif">
					WLWD 2000 Inc. completed docu-drama MISTAKEN IDENTITY with a period of 9 months, filming throughout the USA. The objective is to inform and educate mainstream America and non-Sikhs around the world to understand Who are Sikhs, What is Sikhism and what Sikh Americans have contributed since 1889 over one hundred years ago. - 2002-12-11</font> </p>
<p><a href="/releases/2002/12/prweb52228.php"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">
					<b>Struggling Single Mom with Fibromayalgia and No Car Puts Out Plea on Her Website For Website Santa's to give Christmas Donations.</b></font></a> <font size="2" face="Verdana, Arial, Helvetica, sans-serif">
					A struggling single mom, has managed to get a website listed in Yahoo in less than 6 months, puts out a special plea for her kids at Christmas! She has used poetry in promoting free to publish articles. A unique approach to getting traffic!
 - 2002-12-09</font> </p>
<p><img src="/images/smallstar.gif" width="10" height="10" align="absmiddle" alt="Upgraded $10.00"><a href="/releases/2002/12/prweb52093.php"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">
					<b>Millions Are Sleeping with Angel Animals</b></font></a> <font size="2" face="Verdana, Arial, Helvetica, sans-serif">
					In a nation with 235 million pets, the growing need people have for finding comfort by cuddling with animals is symptomatic of our troubled times.
 - 2002-12-07</font> </p>
<p><a href="/releases/2002/12/prweb52098.php"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">
					<b>"A Journey into the Dark and Dangerous Middle East World of International Assassination and Terrorism."</b></font></a> <font size="2" face="Verdana, Arial, Helvetica, sans-serif">
					Author W. Robb Robichaud is pleased to announce the released of his new novel. - 2002-12-07</font> </p>
<p><img src="/images/smallstar.gif" width="10" height="10" align="absmiddle" alt="Upgraded $10.00"><a href="/releases/2002/12/prweb51852.php"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">
					<b>What Color is Your Pink Slip?</b></font></a> <font size="2" face="Verdana, Arial, Helvetica, sans-serif">
					Looking at a lay-off notice with 'BizNiche Vision can make it turn "green."  If this sounds like a "mood ring," indeed it should.  According to experts (like Josh Reynolds, "mood ring" inventor, who also pioneered studies in biofeedback, psycho-physiology, molecular electronics and air ionization) "visualization of success may help improve self-confidence.  Self-confidence, self-esteem and a positive attitude about one�s abilities are important to optimum performance." - 2002-12-05</font> </p>
<p><img src="/images/smallstar.gif" width="10" height="10" align="absmiddle" alt="Upgraded $30.00"><img src="/images/smallstar.gif" width="10" height="10" align="absmiddle" alt="Upgraded $30.00"><img src="/images/smallstar.gif" width="10" height="10" align="absmiddle" alt="Upgraded $30.00"><a href="/releases/2002/11/prweb51200.php"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">
					<b>Download Your Safety, Protection, Security & Peace of Mind!</b></font></a> <font size="2" face="Verdana, Arial, Helvetica, sans-serif">
					Before you invest your time and money with anti-terrorism and/or crime prevention resources, check with expert William B. Doyle. If you've ever wanted to increase your, your family's and/or your friends' safety, protection, security and peace of mind, download the new 12 volume anti-terrorism & crime prevention "HARD TARGET" electronic book ("ebook") series at 50% off!  - 2002-11-26</font> </p>
</UL> </p>
            <blockquote> 
              <p> <font size="2" face="Verdana, Arial, Helvetica, sans-serif"> 
                <a href="/byindustry.php?prcatid=62&offset=0">1</a> 
<a href="/byindustry.php?prcatid=62&offset=20">2</a> 
<a href="/byindustry.php?prcatid=62&offset=40">3</a> 
<a href="/byindustry.php?prcatid=62&offset=60">4</a> 
<a href="/byindustry.php?prcatid=62&offset=80">5</a> 
<a href="/byindustry.php?prcatid=62&offset=100">6</a> 
<a href="/byindustry.php?prcatid=62&offset=120">7</a> 
<a href="/byindustry.php?prcatid=62&offset=140">8</a> 
<a href="/byindustry.php?prcatid=62&offset=160">9</a> 
<a href="/byindustry.php?prcatid=62&offset=20"><B>NEXT</B></a><p>
 </font></p>
            </blockquote>
                      
            <blockquote>&nbsp;</blockquote>
            <form name="form2" method="post" action="">
            </form></td>
        </tr>
      </table>
      <p>&nbsp;</p></td>
  </tr>
</table>
<br>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
  <tr align="left" valign="bottom" bgcolor="#000066"> 
    <td colspan="2" valign="top"><p><img src="images/blue_tile.gif" width="5" height="17"></p></td>
  </tr>
  <tr align="left" valign="bottom"> 
    <td valign="top">&nbsp;</td>
    <td align="center" valign="bottom"><div align="left"> 
        <table width="95%" border="0" align="center">
          <tr>
            <td><font color="#000000" size="2" face="Verdana, Arial, Helvetica, sans-serif"><font size="1"><strong><br>
              Disclaimer: </strong>If you have any questions regarding information 
              in these press releases please contact the company listed in the 
              press release. Please do not contact PRWeb. We will be unable to 
              assist you with your inquiry. PRWeb disclaims any content contained 
              in these release. Our complete disclaimer appears <a href="disclaimer.php">here</a>.</font></font></td>
          </tr>
        </table>
        <p align="center"><font color="#000000" size="2" face="Verdana, Arial, Helvetica, sans-serif"><font color="#000000" size="2" face="Verdana, Arial, Helvetica, sans-serif">&copy; 
          Copyright 1997-2003, PRWeb. All Rights Reserved</font><font size="1"><br>
          </font> </font></p>
        </div></td>
  </tr>
</table>
<p>&nbsp;</p>






<!--
     FILE ARCHIVED ON 9:18:19 Feb 7, 2003 AND RETRIEVED FROM THE
     INTERNET ARCHIVE ON 0:55:49 Aug 15, 2011.
     JAVASCRIPT APPENDED BY WAYBACK MACHINE, COPYRIGHT INTERNET ARCHIVE.

     ALL OTHER CONTENT MAY ALSO BE PROTECTED BY COPYRIGHT (17 U.S.C.
     SECTION 108(a)(3)).
-->








<script type="text/javascript">
  var wmNotice = "Wayback - External links, forms, and search boxes may not function within this collection. Url: http://ww1.prweb.com:80/byindustry.php?prcatid=62 time: 9:18:19 Feb 07, 2003";
  var wmHideNotice = "hide";
</script>
<script type="text/javascript" src="http://staticweb.archive.org/js/disclaim.js"></script>
</BODY>
</HTML>

