
<html>

<head><base href="http://www.rossello.com:80/rossello.php" />
<meta http-equiv="Content-Language" content="es">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta name="GENERATOR" content="Microsoft FrontPage 5.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<title>ROSSELLO CAMPA�A 2004</title>
<link rel="stylesheet" type="text/css" href="estilo2.css">
<link rel="stylesheet" type="text/css" href="./rosselloStyles.css">
<script language="JavaScript" fptype="dynamicanimation">
<!--
function dynAnimation() {}
function clickSwapImg() {}
//-->
</script>
<script language="JavaScript1.2" fptype="dynamicanimation" src="animate.js">
</script>


</head>

<body topmargin="6" bgcolor="#ECE9D8" onload="dynAnimation()" link="#000000" vlink="#214766" alink="#000000" background="ima-n/bg.gif">
<div align="center">
<table border="0" cellpadding="0" cellspacing="0" width="780" bgcolor="#FFFFFF">
    <tr>
        <td style="padding: 3px; ">
<table border="0" cellpadding="0" cellspacing="0" width="780" bgcolor="#FFFFFF">
    <tr>
        <td valign="top" colspan="3">
            <!-- begin mainheader -->

<script language="JavaScript" fptype="dynamicanimation">
<!--
function dynAnimation() {}
function clickSwapImg() {}
//-->
</script>
<script language="JavaScript1.2" fptype="dynamicanimation" src="file:///C:/Program%20Files/Microsoft%20Office/Office10/fpclass/animate.js">
</script>

<table width="100%" cellpadding="0" cellspacing="0">
 <tr>
  <td>
  <table border="0" width="100%" cellspacing="0" cellpadding="0">
   <tr>
    <td width="41%">
    <p style="margin-left: 30">
    <img border="0" src="prtop.jpg" width="348" height="88">
    </td>
    <td width="59%" align="right">
    <table border="0" width="100%" cellspacing="0" cellpadding="0">
     <tr>
      <td width="14%"><a onmouseover="document['fpAnimswapImgFP17'].imgRolln=document['fpAnimswapImgFP17'].src;document['fpAnimswapImgFP17'].src=document['fpAnimswapImgFP17'].lowsrc;" onmouseout="document['fpAnimswapImgFP17'].src=document['fpAnimswapImgFP17'].imgRolln" href="http://www.laobraderossello.com"><img border="0" src="ima-n/bot/obras.gif" width="64" height="80" id="fpAnimswapImgFP17" name="fpAnimswapImgFP17" dynamicanimation="fpAnimswapImgFP17" lowsrc="ima-n/bot/obras-b.gif"></a></td>
      <td width="85%">
      <img border="0" src="gob1.jpg" width="370" height="28"></td>
      <td width="15%">
      <p align="right">&nbsp;</td>
     </tr>
    </table>
    </td>
   </tr>
  </table>
  </td>
 </tr>
 <tr>
  <td width="100%" valign="bottom" align="right">
  <table border="0" width="100%" cellspacing="0" cellpadding="0">
   <tr>
    <td width="50%" align="left">
     <SCRIPT LANGUAGE="Javascript"><!--
function randimg() { } ; r = new randimg() ; n = 0

//-------------Database----------
r[n++]= '<IMG SRC="plecas/1.jpg" WIDTH="390" HEIGHT="170" ALT="1">'
r[n++]= '<IMG SRC="plecas/2.jpg" WIDTH="390" HEIGHT="170" ALT="1">'
r[n++]= '<IMG SRC="plecas/3.jpg" WIDTH="390" HEIGHT="170" ALT="1">'
r[n++]= '<IMG SRC="plecas/4.jpg" WIDTH="390" HEIGHT="170" ALT="1">'
r[n++]= '<IMG SRC="plecas/5.jpg" WIDTH="390" HEIGHT="170" ALT="1">'
r[n++]= '<IMG SRC="plecas/6.jpg" WIDTH="390" HEIGHT="170" ALT="1">'
r[n++]= '<IMG SRC="plecas/7.jpg" WIDTH="390" HEIGHT="170" ALT="1">'
r[n++]= '<IMG SRC="plecas/8.jpg" WIDTH="390" HEIGHT="170" ALT="1">'
r[n++]= '<IMG SRC="plecas/9.jpg" WIDTH="390" HEIGHT="170" ALT="1">'
r[n++]= '<IMG SRC="plecas/10.jpg" WIDTH="390" HEIGHT="170" ALT="1">'
r[n++]= '<IMG SRC="plecas/11.jpg" WIDTH="390" HEIGHT="170" ALT="1">'
r[n++]= '<IMG SRC="plecas/12.jpg" WIDTH="390" HEIGHT="170" ALT="1">'
r[n++]= '<IMG SRC="plecas/14.jpg" WIDTH="390" HEIGHT="170" ALT="1">'
r[n++]= '<IMG SRC="plecas/15.jpg" WIDTH="390" HEIGHT="170" ALT="1">'
r[n++]= '<IMG SRC="plecas/16.jpg" WIDTH="390" HEIGHT="170" ALT="1">'
r[n++]= '<IMG SRC="plecas/17.jpg" WIDTH="390" HEIGHT="170" ALT="1">'



//----------------------

i=Math.floor(Math.random() * n) ; 
document.write( r[i] )
//--></SCRIPT>
    </td>
    <td width="50%" align="right">
    <img border="0" src="puebloo.jpg" width="358" height="169"></td>
   </tr>
  </table>
  </td>
 </tr>
</table>
<!-- /close mainheader -->        </td>
    </tr>
    <tr>
        <td width="150" bgcolor="#214766" valign="top">
            <!--
    Table containing left column content
-->
<meta http-equiv="Content-Language" content="en-us">
<script language="JavaScript" fptype="dynamicanimation">
<!--
function dynAnimation() {}
function clickSwapImg() {}
//-->
</script>
<script language="JavaScript1.2" fptype="dynamicanimation" src="file:///C:/Program%20Files/Microsoft%20Office/Office10/fpclass/animate.js">
</script>
<script language="JavaScript">
<!-- hide script
    var calwin;
    function openCal( winName ) {
        window.open( "",winName, 'WIDTH=810,HEIGHT=700,resizable=yes,scrollbars=yes,status=yes,toolbar=yes,location=yes' );
    }// openCal()
    function NewWindow() {
				ShowResults=window.open("","PollResults","toolbar=no,scrollbars=yes,directories=no,status=no,menubar=no,resizable=yes,width=600,height=500");
				ShowResults.focus();
				}
				// end hiding scripts -->
</script>
<!-- /leftcontent -->

<body onload="dynAnimation()">

<table border="0" width="150" cellspacing="0" cellpadding="0" bgcolor="#214766">
 <tr>
  <td width="100%"><a onmouseover="document['fpAnimswapImgFP1'].imgRolln=document['fpAnimswapImgFP1'].src;document['fpAnimswapImgFP1'].src=document['fpAnimswapImgFP1'].lowsrc;" onmouseout="document['fpAnimswapImgFP1'].src=document['fpAnimswapImgFP1'].imgRolln" href="rossello.php?src=noticias"><img border="0" src="ima-n/bot/noticias.gif" id="fpAnimswapImgFP1" name="fpAnimswapImgFP1" dynamicanimation="fpAnimswapImgFP1" lowsrc="ima-n/bot/noticias-b.gif" width="150" height="21"></a></td>
 </tr>
 <!--<tr>
  <td width="100%"><a onmouseover="document['fpAnimswapImgFP2'].imgRolln=document['fpAnimswapImgFP2'].src;document['fpAnimswapImgFP2'].src=document['fpAnimswapImgFP2'].lowsrc;" onmouseout="document['fpAnimswapImgFP2'].src=document['fpAnimswapImgFP2'].imgRolln" href="https://rossello.securelook.com/"><img border="0" src="ima-n/bot/aportaciones.gif" id="fpAnimswapImgFP2" name="fpAnimswapImgFP2" dynamicanimation="fpAnimswapImgFP2" lowsrc="ima-n/bot/aportaciones-b.gif" width="150" height="21"></a></td>
 </tr> -->
 <tr>
  <td width="100%"><a onmouseover="document['fpAnimswapImgFP3'].imgRolln=document['fpAnimswapImgFP3'].src;document['fpAnimswapImgFP3'].src=document['fpAnimswapImgFP3'].lowsrc;" onmouseout="document['fpAnimswapImgFP3'].src=document['fpAnimswapImgFP3'].imgRolln" href="rossello.php?src=platafor"><img border="0" src="ima-n/bot/plataforma.gif" id="fpAnimswapImgFP3" name="fpAnimswapImgFP3" dynamicanimation="fpAnimswapImgFP3" lowsrc="ima-n/bot/plataforma-b.gif" width="150" height="21"></a></td>
 </tr>
 <!--<tr>
  <td width="100%"><a onmouseover="document['fpAnimswapImgFP4'].imgRolln=document['fpAnimswapImgFP4'].src;document['fpAnimswapImgFP4'].src=document['fpAnimswapImgFP4'].lowsrc;" onmouseout="document['fpAnimswapImgFP4'].src=document['fpAnimswapImgFP4'].imgRolln" href="rossello.php?src=talento"><img border="0" src="ima-n/bot/banco.gif" id="fpAnimswapImgFP4" name="fpAnimswapImgFP4" dynamicanimation="fpAnimswapImgFP4" lowsrc="ima-n/bot/banco-b.gif" width="150" height="21"></a></td>
 </tr> -->
 <tr>
  <td width="100%"><a onmouseover="document['fpAnimswapImgFP5'].imgRolln=document['fpAnimswapImgFP5'].src;document['fpAnimswapImgFP5'].src=document['fpAnimswapImgFP5'].lowsrc;" onmouseout="document['fpAnimswapImgFP5'].src=document['fpAnimswapImgFP5'].imgRolln" href="rossello.php?src=labase"><img border="0" src="ima-n/bot/labase.gif" id="fpAnimswapImgFP5" name="fpAnimswapImgFP5" dynamicanimation="fpAnimswapImgFP5" lowsrc="ima-n/bot/labase-b.gif" width="150" height="21"></a></td>
 </tr>
 <tr>
  <td width="100%"><a onmouseover="document['fpAnimswapImgFP6'].imgRolln=document['fpAnimswapImgFP6'].src;document['fpAnimswapImgFP6'].src=document['fpAnimswapImgFP6'].lowsrc;" onmouseout="document['fpAnimswapImgFP6'].src=document['fpAnimswapImgFP6'].imgRolln" href="rossello.php?src=recruit"><img border="0" src="ima-n/bot/voluntariostex.gif" id="fpAnimswapImgFP6" name="fpAnimswapImgFP6" dynamicanimation="fpAnimswapImgFP6" lowsrc="ima-n/bot/voluntariostex-b.gif" width="150" height="21"></a></td>
 </tr>
 <!--<tr>
  <td width="100%"><a onmouseover="document['fpAnimswapImgFP7'].imgRolln=document['fpAnimswapImgFP7'].src;document['fpAnimswapImgFP7'].src=document['fpAnimswapImgFP7'].lowsrc;" onmouseout="document['fpAnimswapImgFP7'].src=document['fpAnimswapImgFP7'].imgRolln" href="javascript:;" onclick="openCal( 'calwin' )" target="calwin"><img border="0" src="ima-n/bot/calendario.gif" id="fpAnimswapImgFP7" name="fpAnimswapImgFP7" dynamicanimation="fpAnimswapImgFP7" lowsrc="ima-n/bot/calendario-b.gif" width="150" height="21"></a></td>
 </tr>-->
 <tr>
  <td width="100%"><a onmouseover="document['fpAnimswapImgFP8'].imgRolln=document['fpAnimswapImgFP8'].src;document['fpAnimswapImgFP8'].src=document['fpAnimswapImgFP8'].lowsrc;" onmouseout="document['fpAnimswapImgFP8'].src=document['fpAnimswapImgFP8'].imgRolln" href="rossello.php?src=escuela"><img border="0" src="ima-n/bot/contactanos.gif" id="fpAnimswapImgFP8" name="fpAnimswapImgFP8" dynamicanimation="fpAnimswapImgFP8" lowsrc="ima-n/bot/contactanos-b.gif" width="150" height="21"></a></td>
 </tr>
 <tr>
  <td width="100%"><a onmouseover="document['fpAnimswapImgFP9'].imgRolln=document['fpAnimswapImgFP9'].src;document['fpAnimswapImgFP9'].src=document['fpAnimswapImgFP9'].lowsrc;" onmouseout="document['fpAnimswapImgFP9'].src=document['fpAnimswapImgFP9'].imgRolln" href="http://www.rossello.com/"><img border="0" src="ima-n/bot/portada.gif" id="fpAnimswapImgFP9" name="fpAnimswapImgFP9" dynamicanimation="fpAnimswapImgFP9" lowsrc="ima-n/bot/portada-b.gif" width="150" height="21"></a></td>
 </tr>
 <tr>
  <td width="100%"><a href="rossello.php?src=maga"><img border="0" src="ima-n/bio.jpg" width="150" height="99"></a></td>
 </tr>
 <tr>
  <td width="100%"><a href="rossello.php?src=labase"><img border="0" src="ima-n/enlaces.gif" width="150" height="31"></a></td>
 </tr>
 <tr>
  <td width="100%" bgcolor="#214766"><img border="0" src="ima-n/tithome/encuesta.gif" width="150" height="27"></td>
 </tr>
 <tr>
  <td width="100%" bgcolor="#214766">

   
   
  <!-- Begin Poll Code -->
 <FORM NAME="free_poll"
 <FORM ACTION="http://touchdowncafe.50megs.com/cgi-bin/pollresults/016" TARGET="PollResults" onSubmit="NewWindow()" METHOD="POST">
<TABLE CELLSPACING=0 CELLPADDING=4 WIDTH=134 BGCOLOR=#CCCCCC BORDER=0
BORDERCOLOR="#111111" style="border-collapse: collapse">
  <TR>
    <TD BGCOLOR=#214766 width="126"><TABLE CELLSPACING=0 CELLPADDING=0 BORDER=0
WIDTH=100%><TR><TD ALIGN=center>&nbsp;</TD></TR></TABLE></TD>
  </TR>
  <TR>
    <TD bgcolor="#214766" width="126">
    <p align="center">
    <b><font face="verdana,arial,sans-serif" size="1" color="#FFFFFF">Quien debe 
    ser el Presidente del Senado?</font></b></p>
     <TABLE BORDER=0>

 <TR>
          <TD VALIGN=top><font color="#FFFFFF"><INPUT TYPE=radio VALUE=1 NAME=poll_answer></font></TD>
          <TD VALIGN=MIDDLE>
          <font face="verdana,arial,sans-serif" size="1" color="#FFFFFF">Pedro 
          Rossell�</font></TD>
        </TR><TR>
          <TD VALIGN=top><font color="#FFFFFF"><INPUT TYPE=radio VALUE=2 NAME=poll_answer></font></TD>
          <TD VALIGN=MIDDLE>
          <font face="verdana,arial,sans-serif" size="1" color="#FFFFFF">Kenneth 
          Mcclintock</font></TD>
        </TR>
      </TABLE>
      <CENTER>
      <font color="#FFFFFF">
      <INPUT TYPE=submit VALUE="Vote" NAME=poll_submit><BR>
                        </font>
                        <a href="http://touchdowncafe.50megs.com/cgi-bin/pollresults/016" Target = Blank>
      <font face="verdana,arial,sans-serif" size="1" color="#FFFFFF">		</a>		<a onclick="NewWindow()" target="PollResults" href="http://touchdowncafe.50megs.com/cgi-bin/pollresults/016"><font color="#FFFFFF">Resultados</font></a></FONT></a><font color="#FFFFFF"><BR>


      </font>


      <p>&nbsp;</p>
      <p>
      <font face="verdana,arial,sans-serif" size="1" color="#FFFFFF">		<a onclick="NewWindow()" target="PollResults" href="http://www.rossello.com/pasados.html"><font color="#FFFFFF">
      Resultados de pasadas encuestas</font></a></FONT></p>


      </CENTER>
                </TD>
        </TR>
    </TABLE>
   
   </p>
   <p>&nbsp;</p>
   <p>&nbsp;</p>
   <p>&nbsp;</p>
   <p>&nbsp;</p>
   <p>&nbsp;</p>
   <p>&nbsp;</p>
   <p>&nbsp;</p>
   <p>&nbsp;</p>
   <p>&nbsp;</p>
   <table>
    <tr>
     <td class="largeWhite">
     &nbsp;</td>
    </tr>
   </table>
  </form>
  </td>
 </tr>
 <tr>
  <td width="100%"></td>
 </tr>
</table>
<!-- leftcontent -->        </td>
        <td width="480" bgcolor="#F4F4F4" valign="top" style="padding-left:3px;padding-right:3px; ">
           <!--
    Table containing center content for main page
-->
<!-- Ricardo Rossello vamos a prevalecer! -->
<style>
<!--
td {
	text-align: left;
	vertical-align: top;
	font-family:Tahoma;
	font-size:11px;
	color:3D3D3D;
}
.t11 {
	font-family: Tahoma;
	font-size: 11px;
	font-style: normal;
}
div.Section1
	{page:Section1;}
span.seccionon
	{}
-->
</style>

<script language="JavaScript">
<!--
function MM_openBrWindow(theURL,winName,features) { //v1.2
window.open(theURL,winName,features);
}
//-->
</script>

<body>

<table border="0" width="100%" cellspacing="0" cellpadding="0">
 <tr>
  <td width="100%" valign="top">
  <OBJECT id=rossello 
codeBase=http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=5,0,42,0 
height=192 width=455 classid=clsid:D27CDB6E-AE6D-11cf-96B8-444553540000><PARAM NAME="movie" VALUE="rossello.swf"><PARAM NAME="bgcolor" VALUE="#24528E"><PARAM NAME="quality" VALUE="high"><PARAM NAME="allowscriptaccess" VALUE="samedomain">
          <embed type="application/x-shockwave-flash"   
pluginspage="http://www.macromedia.com/go/getflashplayer"   width="472" 
height="200"   name="rossello" src="rossello.swf"   bgcolor="#24528E" 
quality="high"   swLiveConnect="true" allowScriptAccess="samedomain"  ></embed></OBJECT></td>
 </tr>
 <tr>
  <td width="100%" valign="top">
  <b>
    <p style="text-align: center"><font size="3" color="#000080">Firme La 
    peticion para la Igualdad </font></p>
  <p>
  <font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#000080">
  Mediante la firma del documento de Petic�on al Congreso y al Presidente de los 
  Estados Unidos de Am�rica ayudaremos a resolver el problema del Estatus 
  Pol�tico de Puerto Rico.</font></p>
    <p>
    <iframe src="http://www.estadidad.org/index.html" height="587" width="98%" name="I1" frameborder="0" scrolling="auto">
                                      </p>

</td>
                                  </tr>
                                  <tr>
                                    <td width="100%" valign="top">
</td>
                                  </tr>
                                  <tr>
                                    <td width="100%" valign="top">
</td>
                                  </tr>
                                  <tr>
                                    <td width="100%" valign="top">
</td>
                                  </tr>
                                </table>
          
                                </td>
                              </tr>
                            </table>
                          </td>
                        </tr>
                      </table>
                    </td>
                </tr>
              </table>
            </td>
          </tr>
        </table>
      </td>
    </tr>
  </table>
</div>

<div align="center">
  <table border="0" width="780" cellspacing="0" cellpadding="0">
    <tr>
      <td width="100%">
        <p align="right" style="margin-top: 10"><a href="http://www.vicomstudio.com" target="_blank"><img border="0" src="ima/logovic.jpg" width="130" height="38"></a></td>
    </tr>
  </table>
</div>
<p align="right" style="margin-top: 10">&nbsp;</p>

<p align="right" style="margin-top: 10">&nbsp;</p>

</body>

</html>
</div>
        <p align="center" style="margin-top: 10"><b>
		<font color="#EC8F3E" size="1">.:: Copyright Kohn Research Group 2004 
		::.</font></b></iframe></p>
    <p>&nbsp;</p>
    </b>
                    
        
   &nbsp;</td>
 </tr>
 <tr>
  <td width="100%" valign="top">
  &nbsp;<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="464" id="AutoNumber7">
   <tr>
    <td width="464"> 
    <p> <b> NOTICIAS RECIENTES</b> <br><br> </td>
   </tr>
   <tr>
    <td width="464" valign="top">
    <table border="0" cellspacing="3" cellpadding="3" width="100%">
<tr>
<td width="50%" valign="top" class="norm"><div align="left"><a href="?src=noticia&id=258" title="Vea la noticia completa"><img src="noticias/img.php?id=258" border="0" align="left" height="60" width="60" alt="">Norma Burgos anuncia oficialmente su apoyo a Rossell� (26 de mayo de 2005) </p></div></td>
<td width="50%" valign="top" class="norm"><div align="left"><a href="?src=noticia&id=257" title="Vea la noticia completa"><img src="noticias/img.php?id=257" border="0" align="left" height="60" width="60" alt="">Garriga Pic� oficializar�a su cambio a bando de Rossell� (Viernes, 20 de mayo de 2005)<br />
</p></div></td>
</tr>
<tr>
<td width="50%" valign="top" class="norm"><div align="left"><a href="?src=noticia&id=256" title="Vea la noticia completa"><img src="noticias/img.php?id=256" border="0" align="left" height="60" width="60" alt="">Asamblea Legislativa vence veto del gobernador (18 de Mayo de 2005)<br />
<br />
</p></div></td>
<td width="50%" valign="top" class="norm"><div align="left"><a href="?src=noticia&id=255" title="Vea la noticia completa"><img src="noticias/img.php?id=255" border="0" align="left" height="60" width="60" alt="">Resultados de la Asamblea General del Partido Nuevo Progresista <br />
</p></div></td>
</table>
    </td>
   </tr>
   <tr>
    <td align="right" class="norm" width="464">
    <p align="center"><!-- <b><font size="3">.:<a href="javascript:MM_openBrWindow('http://www.rossello.com/rege.html','Window','status=no,scrollbars=yes,menubar=yes,width=800,height=500')">El ReggaeTurn de Rossell�:.&nbsp;
    </a></font></b> </p> -->
    <p align="right"> <a href="?src=noticias">Mas
      Noticias :::</a></p>
    </td>
    
       </tr>
   <tr>
    <td width="464" class="largeRed"> <b>
    <hr size="1" color="#999999">
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p><a href="http://www.rossello.com/pdf/PJR1505.pdf">Descarga el Mensaje del 
    Dr. Rossell� ante la Asamblea General (PDF)</a>&nbsp;
                        <span lang="en-us">
                        <font face="Arial" size="2">
                        <a href="http://www.adobe.com/products/acrobat/readstep2.html" target = blank>
                        <img border="0" src="/adobe_sm.gif" width="33" height="31"></a></font></span></p>
    <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%">
      <tr>
        <td width="100%">
        <b>
    <hr size="1" color="#999999">
    </b>
                    
        
        </td>
      </tr>
    </table>
    <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%">
      <tr>
    <td width="50%">
    <p style="margin-left: 20; margin-right: 15"> <font face="Arial Black" size="2" color="#003663">
    �Lea el Programa de Gobierno Completo!</font>
    <p style="margin-left: 20; margin-right: 15"> <font color="#003663"> Para 
    Descargar el plan completo haga <a href="http://www.rossello.com/pg.pdf">
    click aqu�</a>. Necesitara el programa Acrobat Reader.&nbsp; </font>
    <p align="right"> <span lang="en-us"> <font face="Times New Roman"> <a href="http://www.adobe.com/" target=blank> 
    Baja Acrobat Aqui <img border="0" src="/adobe_sm.gif" width="33" height="31"></a></font></span>
    <p align="right"> <span lang="en-us"><font face="Times New Roman"> <a href="?src=platafor">
    Lea el programa sin Acrobat Aqui:::</a></font></span> 
    </td>
    <td width="50%" valign="top">
    <p align="center">
    <p align="center"><a href="http://www.rossello.com/pg.pdf"> <img border="1" src="ima/programgob.jpg" width="200" height="202"></a> 
    
    <!--  esta es el codigo para otras secciones
    
        <td width="464" class="largeRed"> <b>
    <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%">
      <tr>
        <td width="100%" colspan="2">
        <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%">
          <tr>
            <td width="100%" colspan="2"> <b>
    <hr size="1" color="#999999">
    </b>
                    
        
            </td>
          </tr>
          <tr>
            <td width="50%">
            <p style="text-align: center">
            <b>
            <a href="http://www.cafepress.com/rossello2004/504662" target = blank>
            <img border="1" src="unsaved:///ima/botipresi.jpg" width="159" height="160"></a></b></td>
            <td width="50%"> <font face="Arial Black" size="2" color="#003663">
            �La Mercanc�a De Rossello Presidente!</font><p>
            <font color="#003663">Demuestra tu apoyo con esta mercanc�a. Ayuda a 
            los damnificados del tsunami con las ganancias.&nbsp;
            <a href="http://www.cafepress.com/rossello2004/504662" target = blank>aqu� </a>
            </font><p>
            &nbsp;</td>
          </tr>
        </table>
        <p>&nbsp;</td>
      </tr>
    </table>
    <hr size="1" color="#999999">
    <p style="text-align: center">
    :: Env�ale una postal electr�nica a tus amigos<font size="1"><span style="line-height: 150%; font-family: Verdana"> </span></font>
            <font style="font-size: 7pt">
            <span style="line-height: 150%; ">
            <a href="http://www.rossello.com/rossello.php?src=ecard" target= blank>
    aqu�!</a> </span></font>
    ::</p>
    <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%">
      <tr>
        <td width="33%">&nbsp;</td>
      </tr>
    </table>
    </b>
                    
        
   </tr>
   -->
    
    
    
    </td>
      </tr>
      </table>
    </b>
                    
        
   </tr>
   </table>
  </td>
 </tr>
 <tr>
  <td width="100%">
  <hr size="1" color="#999999" width="98%">
  </td>
 </tr>
 <td width="100%" valign="top">
  <div align="center">
   <table border="0" width="100%" cellspacing="5" cellpadding="0">
    <tr>
     <td width="50%" bgcolor="#E6E6E6" valign="top">
     <table border="0" width="100%" cellspacing="0" cellpadding="0">
      <tr>
       <td width="100%" bgcolor="#002B55">
       <p align="center" style="margin-top: 2; margin-bottom: 2"> <b><font color="#FFFFFF">
       Enlace&nbsp;
          de la semana</font></b> 
       </td>
      </tr>
      <tr>
       <td width="100%" bgcolor="#E6E6E6">
       <p style="margin-top: 10" align="center"> 
       <a href="http://www.tiendaestadista.com" target=blank>
       <img border="0" src="ima/tiendaest.jpg" width="148" height="117"></a>
    
       <p style="margin-top: 10" align="center"> La tienda estadista tiene una 
       variedad de art�culos para el estadista de coraz�n.&nbsp;&nbsp;
       <a href="rossello.php?src=labase">.:Mas Enlaces:.</a></td>
      </tr>
      <tr>
       <td width="100%" colspan="2"></td>
      </tr>
     </table>
     </td>
     <td width="50%" valign="middle" bgcolor="#E6E6E6">
     <ul style="color: #CC3300" type="square">
      <b><font color="#003663">
      <img border="0" src="ima/audios.jpg" width="79" height="20"></font></b><li>
       <p class="MsoNormal" style="margin-left: -10; margin-right: 10; margin-top: 10; margin-bottom: 10"> 
       <a href="/dalerossello.mp3">Dale Rossello</a></li>
      <li>
       <p class="MsoNormal" style="margin-left: -10; margin-right: 10; margin-top: 10; margin-bottom: 10"> 
       <a href="selevanta.wma">Puerto Rico Se Levanta</a></li>
      <li>
       <p class="MsoNormal" style="margin-left: -10; margin-right: 10; margin-top: 10; margin-bottom: 10"> 
       <a href="mp3/triunfo.mp3">Al Triunfo Con Rossello</a></li>
      <li>
       <p class="MsoNormal" style="margin-left: -10; margin-right: 10; margin-top: 10; margin-bottom: 10"> 
       <a href="/mp3/SoyPNP.mp3">Soy PNP</a></li>
      <li>
       <p class="MsoNormal" style="margin-left: -10; margin-right: 10; margin-top: 10; margin-bottom: 10"> 
       <a href="http://www.rossello.com/mp3/puertorico.wma">
        Puerto Rico (al Rescate)</a></li>
      <li>
       <p class="MsoNormal" style="margin-left: -10; margin-right: 10; margin-top: 10; margin-bottom: 10"> <a href="?src=jingle">�M�s 
       Jingles, Videos y Audios!</a></li>
     </ul>
     </td>
    </tr>
   </table>
  </div>
  </td>
 </tr>
</table>        </td>
        <td width="150" bgcolor="#F4F4F4" valign="top" align="left">
            		<!--  begin rightcontent -->

        <script language="JavaScript" fptype="dynamicanimation">
<!--
function dynAnimation() {}
function clickSwapImg() {}
//-->
        </script>
        <script language="JavaScript1.2" fptype="dynamicanimation" src="file:///C:/Program%20Files/Microsoft%20Office/Office10/fpclass/animate.js">
        </script>

<table border="0" width="150" cellspacing="0" cellpadding="0">
              <tr>
                <td width="100%" valign="top" height="25" bgcolor="#F4F4F4">
                  <p style="margin-top: 5"><img border="0" src="http://www.rossello.com/team.jpg" width="150" height="15"><br>
				</td>
              </tr>
              <tr>
                <td width="100%" height="21" bgcolor="#F4F4F4">
				<form method="POST" action="./newsletterAction.php">
                <!--webbot bot="SaveResults" u-file="C:\Disco D\KARLA\rossello\pagina nuevo layout\_private\form_results.csv" s-format="TEXT/CSV" s-label-fields="TRUE" -->
                  <p style="MARGIN: 5px" align="left"><input size="17" value="Su e-mail" name="email"><br>
                  <input type="radio" CHECKED value="subscribe" name="newsletter">Subscribe<br>
                  <input type="radio" value="unsubscribe" name="newsletter">Unsubscribe</p>
                  <p style="MARGIN: 5px" align="center"><img height="3" src="ima-n/trans.gif" width="4" border="0"><br>
                  <input class="norm" type="submit" value="Inscribete" name="B1">
																		</form></td>
              </tr>
        </td>
    </tr>
    <tr>
        <td width="780" bgcolor="#999999" valign="top" colspan="3">
             
 	  <!-- begin footer --> 
           <!-- <p align="center"><span style="font-size: 10pt; mso-bidi-font-family: MS Shell Dlg"><font size="2" color="#FFFFFF"><font color="black" size="2"><span style="font-size: 10pt; color: black; mso-bidi-font-family: MS Shell Dlg"><span class="SpellE"><a href="mailto:ricky@rossello.com">Contacto</a></span>
            </span></font></font><font color="#FFFFFF"><span class="SpellE"><font color="black" size="2"><span style="font-size: 10pt; color: black; mso-bidi-font-family: MS Shell Dlg">
            - </span></font></span><span style="font-size: 10pt; color: black; mso-bidi-font-family: MS Shell Dlg"><font color="black" size="2"><span class="SpellE">
            </span></font></span></font><span style="font-size: 10pt; color: black; mso-bidi-font-family: MS Shell Dlg"><font color="black" size="2"><font size="2" color="#FFFFFF"><span class="SpellE"><a href="http://www.rossellomail.com/" target="_blank">Rossellomail</a></span>
            </font>-&nbsp; <span style="mso-spacerun: yes">&nbsp;</span><span class="SpellE"><a href="http://www.rossello.tv" target="_blank">Rossello.tv</a></span>
            </font></span><font size="2" color="#FFFFFF"><span style="FONT-SIZE: 10pt; COLOR: black; FONT-FAMILY: 'MS Shell Dlg'; mso-bidi-font-family: 'MS Shell Dlg'"><font face="MS Shell Dlg" color="black" size="2"><o:p>
            </o:p> -->
            </font></span></font></span>
          </td>
        </tr>
        <tr>
          <td width="100%" valign="top" bgcolor="#214766" colspan="3">
            <p style="margin-top: 3; margin-bottom: 3" align="center"><span style="font-size: 10pt; mso-bidi-font-family: MS Shell Dlg"><font size="2" color="#FFFFFF">Copyright
            Rossello.com &nbsp; </font></span>
 	  <!-- /footer -->         </td>
    </tr>
</table>
        </td>
    </tr>
</table>
</div>





<!--
     FILE ARCHIVED ON 13:51:11 Feb 25, 2008 AND RETRIEVED FROM THE
     INTERNET ARCHIVE ON 1:07:06 Aug 15, 2011.
     JAVASCRIPT APPENDED BY WAYBACK MACHINE, COPYRIGHT INTERNET ARCHIVE.

     ALL OTHER CONTENT MAY ALSO BE PROTECTED BY COPYRIGHT (17 U.S.C.
     SECTION 108(a)(3)).
-->








<script type="text/javascript">
  var wmNotice = "Wayback - External links, forms, and search boxes may not function within this collection. Url: http://www.rossello.com:80/rossello.php time: 13:51:11 Feb 25, 2008";
  var wmHideNotice = "hide";
</script>
<script type="text/javascript" src="http://staticweb.archive.org/js/disclaim.js"></script>
</body>

</html>