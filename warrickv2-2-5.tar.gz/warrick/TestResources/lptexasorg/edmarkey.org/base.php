<html>

<head><base href="http://www.edmarkey.org/base.php" />
<title>Congressman Edward J. Markey</title>
<link rel="stylesheet" href="./css/markey.css">
<script src="./js/markey.js" type="text/javascript"></script>
</head>

<body>
<table>
	<tr>
		<td style="background-color:#023D6B;width:825px;height:12px;"><img src="./images/shim.gif" alt="" /></td>
	</tr>
</table>
<table>
	<tr>
		<td style="background-color:#ffffff;width:1px;height:2px;"><img src="./images/shim.gif" alt="" /></td>
	</tr>
</table>
<table>
	<tr>
		<td style="background-color:#9c0000;width:825px;height:6px"><img src="./images/shim.gif" alt="" /></td>
	</tr>
</table>
<table>
	<tr>
		<td style="background-color:#ffffff;width:1px;height:6px;"><img src="./images/shim.gif" alt="" /></td>
	</tr>
</table>
<table cellpadding="0" cellspacing="0" style="width:825px">
	<tr>
		<td valign="top" style="height:76px"><a href="./index.php"><img src="./images/banner_name.gif" width="317" height="76" border="0" alt="" /></a></td>
		<td>
			<table cellpadding="0" cellspacing="0">
				<tr>
					<td valign="top"><img src="./images/banner_flag.jpg" width="192" height="40" alt="" /><a href="javascript:popPage('joinNow.html')" onmouseup=""><img src="./images/banner_join.jpg" width="143" height="40" border="0" alt="Join Us Now!" /></a><a href="javascript:popPage('https%3A%2F%2Fservices.myngp.com%2Fngponlineservices%2Fcontribution.aspx%3FX%3DH0%252bp%252b1ss4hk5lY6sPORwng%253d%253d')" onmouseup=""><img src="./images/banner_contribute.jpg" width="173" height="40" border="0" alt="Contribute Now!" /></a></td>
				</tr>
				<tr>
					<td valign="top">
						<ul id="nav">
							<li class="mybackground"><div><a href="./markey_background.php" target="_top"><img src="./images/nav_bg.gif" border="0" alt="My Background" /></a></div>
								<ul>
									<li class="dropLinkText"><a href="./markey_background.php" target="_top">HIS BACKGROUND</a></li>
									<li class="dropLinkText"><a href="./markey_public_advocate.php" target="_top">PUBLIC INTEREST ADVOCATE</a></li>
									<li class="dropLinkText"><a href="./markey_legislator.php" target="_top">LANDMARK LEGISLATOR</a></li>
									<li class="dropLinkText"><a href="./markey_consumer_champ.php" target="_top">CONSUMER CHAMPION</a></li>
									<li class="dropLinkText"><a href="./markey_testimonials.php" target="_top">WHAT OTHERS SAY</a></li>
								</ul>
							</li>
							<li class="whereistand"><div><a href="./markey_iraq_war.php" target="_top"><img src="./images/nav_stand.gif" border="0" alt="Where Ed Stands" /></a></div>
								<ul>
									<li class="dropLinkText"><a href="#" onmouseover="showMenu('world','nation','people')">OUR WORLD</a>
										<ul id="world">
											<li class="dropLinkText"><a href="./markey_iraq_war.php" target="_top">WAR IN IRAQ</a></li>
											<li class="dropLinkText"><a href="./markey_environment.php" target="_top">ENVIRONMENT</a></li>
											<li class="dropLinkText"><a href="./markey_energy.php" target="_top">ENERGY</a></li>
											<li class="dropLinkText"><a href="./markey_nuclear_weapons.php" target="_top">NUCLEAR WEAPONS</a></li>
											<li class="dropLinkText"><a href="./markey_human_rights.php" target="_top">HUMAN RIGHTS</a></li>
										</ul>
									</li>
									<li class="dropLinkText"><a href="#" onmouseover="showMenu('nation','world','people')">OUR STATE &amp; NATION</a>
										<ul id="nation">
											<li class="dropLinkText"><a href="./markey_economy.php" target="_top">ECONOMIC DEVELOPMENT</a></li>
											<li class="dropLinkText"><a href="./markey_health_care.php" target="_top">HEALTH CARE</a></li>
											<li class="dropLinkText"><a href="./markey_homeland_security.php" target="_top">HOMELAND SECURITY</a></li>
											<li class="dropLinkText"><a href="./markey_education.php" target="_top">EDUCATION</a></li>
											<li class="dropLinkText"><a href="./markey_telecom.php" target="_top">TELECOMMUNICATIONS</a></li>
											<li class="dropLinkText"><a href="./markey_immigration.php" target="_top">IMMIGRATION</a></li>
										</ul>
									</li>
									<li class="dropLinkText" onmouseover="showMenu('people','world','nation')"><a href="#" >OUR PEOPLE</a>
										<ul id="people">
											<li class="dropLinkText"><a href="./markey_privacy.php" target="_top">PRIVACY</a></li>
											<li class="dropLinkText"><a href="./markey_womens_issues.php" target="_top">WOMEN</a></li>
											<li class="dropLinkText"><a href="./markey_childrens_issues.php" target="_top">CHILDREN</a></li>
											<li class="dropLinkText"><a href="./markey_veterans.php" target="_top">VETERANS</a></li>
											<li class="dropLinkText"><a href="./markey_civil_rights.php" target="_top">CIVIL RIGHTS</a></li>
										</ul>
									</li>
								</ul>
							</li>
							<li class="headlines"><div><a href=""><img src="./images/nav_headlines.gif" border="0" alt="Headlines" /></a></div></li>
							<li class="act"><div><a href=""><img src="./images/nav_act.gif" border="0" alt="Act!" /></a></div>
								<ul>
									<li class="dropLinkText"><a href="https://services.myngp.com/ngponlineservices/volunteer.aspx?X=H0%2bp%2b1ss4hkcPdnu1X7sdA%3d%3d" target="_top">VOLUNTEER</a></li>
									<li class="dropLinkText"><a href="https://services.myngp.com/ngponlineservices/contribution.aspx?X=H0%2bp%2b1ss4hk5lY6sPORwng%3d%3d" target="_top">CONTRIBUTE</a></li>
									<li class="dropLinkText"><a href="./markey_register_vote.php" target="_top">REGISTER TO VOTE</a></li>
									<li class="dropLinkText"><a href="./markey_tell_friend.php" target="_top">TELL A FRIEND</a></li>
									<li class="dropLinkText"><a href="http://www.massdems.org/" target="_top">STATE PARTY</a></li>
								</ul>
							</li>
							<li class="gear"><div><a href="./markey_gear.php"><img src="./images/nav_gear.gif" border="0" alt="Markey Gear" /></a></div></li>
							<li class ="kerry"><div><img src="./images/nav_kerry.gif" border="0" alt="Kerry Connection" /></div></li>
						</ul>
					</td>
				</tr>
			</table>
		</td>
	</tr>
</table>
<table style="width:825px;" cellpadding="0" cellspacing="0">
	<tr>
		<td style="background-color:#9c0000;width:5px;height:42px"><img src="./images/shim.gif" alt="" /></td>
		<td style="vertical-align:bottom;text-align:right;padding-right:5px;"><a href="./markey_tell_friend.php"><img src="./images/markey_tellafriend.gif" border="0" alt="" /></a></td>
		<td style="background-color:#9c0000;width:5px;height:42px"><img src="./images/shim.gif" alt="" /></td>
	</tr>
</table>

<table style="width:825px" cellpadding="0" cellspacing="0">
	<tr>
		<td style="background-color:#9c0000;width:5px;height:411px"><img src="./images/shim.gif" alt="" /></td>
		
					<td align="center"><img src="./images/markey_champ.jpg" border="0" alt="" /><p>Congressman Ed Markey</p>
</td>
				
		<td style="vertical-align:top;">
		<div id="content">
			<h1></h1>

<p style="text-align:left">
<p>
</p>
<p style='text-align:right'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p><div id="hlineouterbox">

				<div id="hlineinnerbox"><center>
<p style="text-align:center">
					<h2>HEADLINES</h2>
			
<br></p>


					
</center>
						</div>
			</div>
		 
		</div>
		
		
		
		<object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,0,0" width="460" height="205" id="pollWidget" align="middle">
<param name="allowScriptAccess" value="sameDomain" />
<param name="movie" value="pollWidget4.swf" />
<param name="quality" value="high" />
<param name="bgcolor" value="#ffffff" />
<embed src="pollWidget4.swf" quality="high" bgcolor="#ffffff" width="460" height="205" name="pollWidget" align="middle" allowScriptAccess="sameDomain" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" />
</object>
		
		</td>
				<td style="background-color:#9c0000;width:5px;height:411px"><img src="./images/shim.gif" alt="" /></td>
	</tr>
</table>
<table style="width:825px" cellpadding="0" cellspacing="0">
	<tr>
		<td style="background-color:#9c0000;width:591px;height:41px"><div style="font-size:12px;color:#ffffff;text-align:left;padding:4px 0px 0px 4px">PAID FOR AND AUTHORIZED BY THE MARKEY COMMITTEE</div></td>
		<td style="background-color:#9c0000;width:100px;padding-right:50px;padding-top:4px;text-align:right;font-family:Times;"><a style="font-size:12px;color:#ffffff;text-decoration:none;" href="./markey_contact.php">CONTACT US</a></td>
		<td><a href="http://www.networkedpolitics.com"><img src="./images/np_logo.gif" border="0" alt="Networked Politics" /></a></td>
	</tr>
	<tr>
	</tr>
</table>





<!--
     FILE ARCHIVED ON 21:11:38 Feb 9, 2007 AND RETRIEVED FROM THE
     INTERNET ARCHIVE ON 1:06:50 Aug 15, 2011.
     JAVASCRIPT APPENDED BY WAYBACK MACHINE, COPYRIGHT INTERNET ARCHIVE.

     ALL OTHER CONTENT MAY ALSO BE PROTECTED BY COPYRIGHT (17 U.S.C.
     SECTION 108(a)(3)).
-->








<script type="text/javascript">
  var wmNotice = "Wayback - External links, forms, and search boxes may not function within this collection. Url: http://www.edmarkey.org/base.php time: 21:11:38 Feb 09, 2007";
  var wmHideNotice = "hide";
</script>
<script type="text/javascript" src="http://staticweb.archive.org/js/disclaim.js"></script>
</body>
</html>