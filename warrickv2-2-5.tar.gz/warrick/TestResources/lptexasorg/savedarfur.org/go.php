


<html>
<head><base href="http://www.savedarfur.org:80/go.php?q=home2.php" />
	<title>Save Darfur.org</title>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	<meta name="keywords" content="genocide, Darfur, Darfurian, Darfurians, Weekend of Prayer, Weekend of Reflection, Weekend of Prayer and Reflection, Sudan, Save Darfur, SaveDarfur, Religious Action, Faith Action,donation, donations">
	<meta name="description" content="The Save Darfur Coalition is an alliance of over 170 diverse faith-based, humanitarian, and human rights organization, assembled to raise public awareness and to mobilize efforts to help end the atrocities and reduce the suffering in Darfur and nearby refugee camps.">
	<link rel="stylesheet" href="/inc/savedarfur.css">
	<link rel="stylesheet" href="/inc/leftmenu/menu.css">
	<script language="JavaScript" src="/inc/leftmenu/menu.js"></script>
	<script language="JavaScript" src="/inc/leftmenu/items.js"></script>
	<script language="JavaScript" src="/inc/leftmenu/template.js"></script>
</head>

<SCRIPT LANGUAGE="JavaScript">
 	function check(theForm) {

		if (theForm.Email.value == "  you@email.com") {
			alert ("        You must enter your email address to join the list.         ");
			return false;
		} else {
			return true;
		}
	}

	var popupWindow;

	function showPopup (fileName, width, height, scrolling, toolbar){
		if (popupWindow && popupWindow.close)
			popupWindow.close();

		scrolling = scrolling ? "scrollbars," : "";
		toolbar = toolbar ? "toolbar," : "";

		var featureString = toolbar + scrolling + "width=" + width + ",height=" + height + ",resizable=yes";

		popupWindow = window.open(fileName, "popupWindow", featureString);
		popupWindow.focus();
	}

	function forSearch(theForm) {
		theForm.q.value += " site:www.savedarfur.org";
		return true;
	}
</SCRIPT>
<body>

<table width="100%" cellpadding="0" cellspacing="0" border="0">
	<tr>
		<td bgcolor="#990000" style="background-image: url(/images/save_darfur_top.gif); background-repeat: no-repeat;">
			<a href="/home"><img src="/images/spacer.gif" width="700" height="140" alt="." border="0"></a></td>
	</tr>
	<tr>
		<td bgcolor="#e5e5e5" valign="top" style="background-image: url(/images/main_column_shadow.gif); background-repeat: repeat-x;">
			<img src="/images/left_column_shadow.gif" width="143" height="7" alt="Save Darfur"></td>
	</tr>
</table>

<table width="723" cellpadding="0" cellspacing="0" border="0">
	<tr>

		<td bgcolor="#e5e5e5" valign="top" align="center">

				<!-- The Email List Box -->
 				<form action="http://demaction.org/dia/api/process.jsp" onSubmit="return check(this)">
				<div style="background-color: #f0f0f0; border-bottom: 1px solid #999; padding: 0px; line-height: 19px; margin: 0px; line-height: 14px; ">
					<a href="javascript:showPopup('/misc/pop_aboutemaillist.html', 400, 300, 'yes')" style="font-weight: bold; text-decoration: none; display: block; background-color: #e5e5e5; font-size: 14px; line-height: 24px;">GET INVOLVED!</a>
					<div style="padding: 5px;">Enter your email to keep informed and get involved.</div>
					<input type=hidden name="org" value="432">
					<input type="hidden" name="orgKey" value="iYsrooUP+BCIZVD9a907J4sCieYhZyL4A85AA0ec5dY=">
					<input type=hidden name="table" value="supporter">
					<input name="Email" value="  you@email.com" onClick="this.value=''" style="background-color: #fff; font-weight: bold; font-size: 12px; color: #666; width: 120; margin-bottom: 5px; margin-top: 7px;">

					<input type=hidden name="redirect"
					value="http://hq.demaction.org/dia/organizations/darfur/signUp.jsp?key=240&Email=[[Email]]"
					>
					<input type="submit" value="> Subscribe" style="width: 120px; font-weight: bold; background-color: #990000; border: 1px solid #fff; color:#fff; margin-bottom: 4px;">
				</div>
				</form>
				<!-- //The Email List Box -->

			<!-- Begin: Main left Menu -->
			<script language="JavaScript">
			new menu (MENU_ITEMS0, MENU_POS0);
			</script>
			<!-- End: Main left Menu -->

				<br>

				<a href="http://store.yahoo.com/yhst-88482264721289/index.html"><img src="/images/button_awarenessstore_left.jpg" border="0" alt="Darfur Awareness Items" style="margin-bottom: 10px;" /></a>

				<br>

				<!-- The Search Box -->
 				<form action="http://google.com/search?" onSubmit="return forSearch(this)">
				<div style="border: 1px solid #999; background-color: #d9d9d9; padding-top: 5px;  padding-bottom: 5px; line-height: 19px; margin-left: 5px; margin-right: 5px; ">
					<span style="font-weight: bold; text-decoration: none;">search this site</span><br>
					<input name="q" value="" onClick="this.value=''" size="10" style="background-color: #eeeeee; font-weight: bold; font-size: 12px; color: #666; width: 120; margin-bottom: 5px;">
					<input type="submit" value="Search" style="width: 120px; border: 1px solid #900; background-color: #999; color: #fff; font-weight: bold;">
				</div>
				</form>
				<!-- //The Search Box -->

				<br>
				<br>
				<br>

		</td>

		<td bgcolor="#ffffff" valign="top" width="580">

			<br>
			<div class="copy">
<!-- End: Main Hi Include (hi.php) -->


<!-- End Header -->

<div class='errorBox'><h1>That page has moved...</h1>The link you clicked on is deprecated. Please try to find what you were looking for by clicking on the menu to the left.</div>
<!-- Begin Footer -->
<!-- Begin: Main Lo Include (lo.php) -->
<br>
<br>
<br>

		</td>
		<td valign="top">
			<br>
					</td>

	</tr>
	<tr>
		<td bgcolor="#e5e5e5">&nbsp;</td>
		<td colspan="2">

			<div id="footer">
				<nobr>
				<a href="/home" class="footerLink">Home</a> |
				<a href="https://secure.democracyinaction.org/dia/organizations/darfur/shop/custom.jsp?donate_page_KEY=1318&track=footer" class="footerLink">Donate Now</a> |
				<a href="/situation" class="footerLink">Situation in Darfur</a> |
				<a href="/news" class="footerLink">Latest News</a> |
				<a href="/action" class="footerLink">Take Action Now</a><br>
				<a href="/faith" class="footerLink">Communities of Faith</a> |
				<a href="/about" class="footerLink">Save Darfur Coalition</a> |
				<a href="/about/contact" class="footerLink">Contact Us</a> |
				<a href="/sitemap" class="footerLink">Site Map</a>
				</nobr>

				<br><br>

				<span class="footerCred">
				Site �2006 by The Save Darfur Coalition &nbsp; | &nbsp; Website made by <a href="http://springthistle.com" target="_new">Springthistle Design</a>
				  |   <br> eLearning Management System:<a href="http://www.eleapsoftware.com" target="_new"> eLeaP</a>
</span>
			</div>

		</td>
	</tr>
</table>








<!--
     FILE ARCHIVED ON 5:26:42 Aug 31, 2006 AND RETRIEVED FROM THE
     INTERNET ARCHIVE ON 1:12:44 Aug 15, 2011.
     JAVASCRIPT APPENDED BY WAYBACK MACHINE, COPYRIGHT INTERNET ARCHIVE.

     ALL OTHER CONTENT MAY ALSO BE PROTECTED BY COPYRIGHT (17 U.S.C.
     SECTION 108(a)(3)).
-->








<script type="text/javascript">
  var wmNotice = "Wayback - External links, forms, and search boxes may not function within this collection. Url: http://www.savedarfur.org:80/go.php?q=home2.php time: 5:26:42 Aug 31, 2006";
  var wmHideNotice = "hide";
</script>
<script type="text/javascript" src="http://staticweb.archive.org/js/disclaim.js"></script>
</body>
</html>

